import { useState } from 'react';
import { Search, MapPin, Calendar, Users, ArrowRight, Compass, Sparkles } from 'lucide-react';
import { Link, useRouter } from '@/router';
import { Reveal } from '@/components/ui';
import { DestinationCard } from '@/components/DestinationCard';
import { DESTINATIONS, JAPAN_COLLECTIONS } from '@/data/catalog';

export function HomePage() {
  const { navigate } = useRouter();
  const [dest, setDest] = useState('');
  const [date, setDate] = useState('');
  const [travelers, setTravelers] = useState('2 travelers');
  const featured = DESTINATIONS.filter((d) => d.featured);
  const japan = DESTINATIONS.find((d) => d.slug === 'japan')!;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/destinations${dest.trim() ? `?q=${encodeURIComponent(dest.trim())}` : ''}`);
  };

  return (
    <>
      {/* HERO */}
      <section className="relative min-h-[100vh] flex items-center overflow-hidden bg-navy-900">
        <img
          src="https://images.pexels.com/photos/4336279/pexels-photo-4336279.jpeg?auto=compress&cs=tinysrgb&h=1400&w=2400"
          alt="Mount Fuji with cherry blossoms and Chureito Pagoda"
          className="absolute inset-0 w-full h-full object-cover animate-ken-burns"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-navy-950/70 via-navy-950/40 to-navy-950/80" />
        <div className="relative container-page pt-28 pb-16">
          <div className="max-w-2xl animate-fade-up">
            <div className="flex items-center gap-2 text-coral-300 mb-4">
              <Sparkles size={16} />
              <span className="text-[0.7rem] tracking-[0.25em] uppercase font-semibold">The World Is Yours to Explore</span>
            </div>
            <h1 className="font-display font-extrabold text-white text-5xl md:text-6xl lg:text-7xl leading-[1.05] mb-5 text-balance">
              Your Next Story Starts Here.
            </h1>
            <p className="text-white/85 text-lg md:text-xl leading-relaxed max-w-lg mb-8">
              Discover extraordinary places, find inspiring stays, and plan journeys worth remembering.
            </p>
          </div>

          {/* Search bar */}
          <form onSubmit={handleSearch} className="glass-card p-4 lg:p-5 max-w-4xl mt-4 animate-fade-up" style={{ animationDelay: '120ms' }}>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div className="relative">
                <label className="text-[0.65rem] tracking-[0.15em] uppercase font-semibold text-navy-500 mb-1.5 block flex items-center gap-1"><MapPin size={11} /> Destination</label>
                <input value={dest} onChange={(e) => setDest(e.target.value)} placeholder="Where to?" className="w-full bg-cloud-100 border-0 px-4 py-2.5 text-sm text-navy-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-coral-400/40" />
              </div>
              <div className="relative">
                <label className="text-[0.65rem] tracking-[0.15em] uppercase font-semibold text-navy-500 mb-1.5 block flex items-center gap-1"><Calendar size={11} /> Travel Dates</label>
                <input value={date} onChange={(e) => setDate(e.target.value)} type="text" placeholder="Add dates" className="w-full bg-cloud-100 border-0 px-4 py-2.5 text-sm text-navy-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-coral-400/40" />
              </div>
              <div className="relative">
                <label className="text-[0.65rem] tracking-[0.15em] uppercase font-semibold text-navy-500 mb-1.5 block flex items-center gap-1"><Users size={11} /> Travelers</label>
                <select value={travelers} onChange={(e) => setTravelers(e.target.value)} className="w-full bg-cloud-100 border-0 px-4 py-2.5 text-sm text-navy-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-coral-400/40">
                  <option>1 traveler</option>
                  <option>2 travelers</option>
                  <option>3 travelers</option>
                  <option>4 travelers</option>
                  <option>5+ travelers</option>
                </select>
              </div>
              <button type="submit" className="btn-coral self-end h-[42px]">
                <Search size={16} /> Search
              </button>
            </div>
          </form>

          <div className="flex flex-wrap gap-3 mt-6 animate-fade-up" style={{ animationDelay: '200ms' }}>
            <Link to="/destinations" className="btn-coral">Explore Destinations</Link>
            <Link to="/japan" className="btn-ghost-light"><Compass size={16} /> Discover Japan</Link>
          </div>
        </div>
      </section>

      {/* FEATURED DESTINATIONS */}
      <section className="container-page py-20">
        <Reveal>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
            <div>
              <p className="eyebrow mb-2">Featured Destinations</p>
              <h2 className="font-display font-extrabold text-4xl md:text-5xl text-navy-700">Where will you go next?</h2>
            </div>
            <Link to="/destinations" className="text-sm font-semibold text-coral-500 link-underline">View all destinations</Link>
          </div>
        </Reveal>

        {/* Japan large feature */}
        <Reveal>
          <DestinationCard destination={japan} large index={0} />
        </Reveal>

        {/* Other destinations grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
          {featured.filter((d) => d.slug !== 'japan').map((d, i) => (
            <DestinationCard key={d.id} destination={d} index={i} />
          ))}
        </div>
      </section>

      {/* JAPAN EDITORIAL FEATURE */}
      <section className="relative py-24 bg-navy-700 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img src="https://images.pexels.com/photos/35072452/pexels-photo-35072452.jpeg?auto=compress&cs=tinysrgb&h=900&w=1600" alt="" aria-hidden className="w-full h-full object-cover" />
        </div>
        <div className="relative container-page grid lg:grid-cols-2 gap-12 items-center">
          <Reveal>
            <div className="grid grid-cols-2 gap-4">
              <div className="img-zoom aspect-[3/4] rounded-2xl overflow-hidden">
                <img src="https://images.pexels.com/photos/31258209/pexels-photo-31258209.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="Tokyo night" className="w-full h-full object-cover" loading="lazy" />
              </div>
              <div className="img-zoom aspect-[3/4] rounded-2xl overflow-hidden mt-10">
                <img src="https://images.pexels.com/photos/29537651/pexels-photo-29537651.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="Fushimi Inari" className="w-full h-full object-cover" loading="lazy" />
              </div>
            </div>
          </Reveal>
          <Reveal delay={120}>
            <p className="eyebrow text-coral-400 mb-3">Signature Destination</p>
            <h2 className="font-display font-extrabold text-white text-4xl md:text-5xl mb-5 text-balance">
              Japan is more than a place. It\'s an experience.
            </h2>
            <p className="text-cloud-100/80 text-lg leading-relaxed mb-6">
              From Tokyo\'s electric energy to Kyoto\'s timeless traditions, from Mount Fuji\'s sacred silhouette to Hokkaido\'s snow country, Japan is a country where ancient culture and modern life meet at every turn.
            </p>
            <div className="flex flex-wrap gap-3 mb-7">
              {JAPAN_COLLECTIONS.slice(0, 4).map((c) => (
                <Link key={c.id} to={`/japan/${c.id}`} className="chip bg-white/10 text-white border-white/20 hover:bg-white/20 transition-colors">{c.name}</Link>
              ))}
            </div>
            <Link to="/japan" className="btn-coral">Discover Japan <ArrowRight size={15} /></Link>
          </Reveal>
        </div>
      </section>

      {/* WHY ROAMORA */}
      <section className="container-page py-20">
        <Reveal>
          <div className="text-center mb-12">
            <p className="eyebrow mb-2">Why ROAMORA</p>
            <h2 className="font-display font-extrabold text-4xl md:text-5xl text-navy-700">Travel, beautifully planned.</h2>
          </div>
        </Reveal>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: Compass, t: 'Discover with intention', d: 'Curated destinations, not an endless list. Every place we feature is chosen for how it feels, not just how it photographs.' },
            { icon: MapPin, t: 'Plan with confidence', d: 'Sample itineraries, travel styles, and seasonal guides help you shape a trip that fits you — not a template.' },
            { icon: Sparkles, t: 'Save what inspires you', d: 'Bookmark destinations and itineraries to your wishlist or trip planner, and build your journey over time.' },
          ].map((f, i) => (
            <Reveal key={f.t} delay={i * 100}>
              <div className="bg-white rounded-2xl p-7 h-full border border-cloud-200 hover:border-coral-400/30 hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 rounded-xl bg-coral-50 flex items-center justify-center mb-4">
                  <f.icon size={22} className="text-coral-500" />
                </div>
                <h3 className="font-display font-bold text-xl text-navy-700 mb-2">{f.t}</h3>
                <p className="text-sm text-navy-500/80 leading-relaxed">{f.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container-page pb-20">
        <Reveal>
          <div className="relative rounded-3xl overflow-hidden h-[360px] lg:h-[420px]">
            <img src="https://images.pexels.com/photos/20385882/pexels-photo-20385882.jpeg?auto=compress&cs=tinysrgb&h=900&w=1600" alt="Swiss Alps" className="absolute inset-0 w-full h-full object-cover" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-r from-navy-950/85 to-navy-950/40" />
            <div className="relative h-full flex flex-col justify-center max-w-xl p-8 lg:p-14">
              <p className="eyebrow text-coral-300 mb-3">Ready when you are</p>
              <h2 className="font-display font-extrabold text-white text-3xl md:text-4xl mb-4 text-balance">The world is waiting. Let\'s find your next journey.</h2>
              <div className="flex flex-wrap gap-3 mt-3">
                <Link to="/destinations" className="btn-coral">Start Exploring</Link>
                <Link to="/japan" className="btn-ghost-light">Plan a Japan Trip</Link>
              </div>
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}
