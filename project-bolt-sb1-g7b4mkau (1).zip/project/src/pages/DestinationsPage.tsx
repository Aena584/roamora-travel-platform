import { useMemo, useState, useEffect } from 'react';
import { Search, SlidersHorizontal, X, Grid3x3, List, ArrowRight, MapPin } from 'lucide-react';
import { Link, useRouter } from '@/router';
import { Reveal } from '@/components/ui';
import { DESTINATIONS, REGIONS, BUDGETS, TRAVEL_STYLES_ALL } from '@/data/catalog';

type SortKey = 'featured' | 'name' | 'budget';

const SEASON_OPTS = ['Spring', 'Summer', 'Autumn', 'Winter', 'Year-round'];

export function DestinationsPage() {
  const { route, navigate } = useRouter();
  const initial = route.query;

  const [region, setRegion] = useState<string>('all');
  const [budget, setBudget] = useState<string>('all');
  const [style, setStyle] = useState<string>('all');
  const [season, setSeason] = useState<string>('all');
  const [search, setSearch] = useState<string>(initial.q ?? '');
  const [sort, setSort] = useState<SortKey>('featured');
  const [view, setView] = useState<'grid' | 'list'>('grid');
  const [visible, setVisible] = useState(6);
  const [filtersOpen, setFiltersOpen] = useState(false);

  useEffect(() => { setSearch(initial.q ?? ''); }, [initial.q]);

  const filtered = useMemo(() => {
    let list = [...DESTINATIONS];
    if (region !== 'all') list = list.filter((d) => d.region === region);
    if (budget !== 'all') list = list.filter((d) => d.budget === budget);
    if (style !== 'all') list = list.filter((d) => d.travelStyles.includes(style));
    if (season !== 'all') {
      const s = season.toLowerCase();
      list = list.filter((d) => d.bestTime.toLowerCase().includes(s) || d.bestTime.toLowerCase().includes('year'));
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter((d) => d.name.toLowerCase().includes(q) || d.country.toLowerCase().includes(q) || d.shortDesc.toLowerCase().includes(q));
    }
    if (sort === 'name') list.sort((a, b) => a.name.localeCompare(b.name));
    if (sort === 'budget') {
      const order = { Budget: 0, 'Mid-range': 1, Luxury: 2 };
      list.sort((a, b) => order[a.budget] - order[b.budget]);
    }
    return list;
  }, [region, budget, style, season, search, sort]);

  const shown = filtered.slice(0, visible);
  const activeCount = (region !== 'all' ? 1 : 0) + (budget !== 'all' ? 1 : 0) + (style !== 'all' ? 1 : 0) + (season !== 'all' ? 1 : 0);

  const clearAll = () => { setRegion('all'); setBudget('all'); setStyle('all'); setSeason('all'); navigate('/destinations'); };

  const Filters = () => (
    <div className="space-y-7">
      <FilterGroup label="Region" options={['all', ...REGIONS]} value={region} onChange={setRegion} formatAll="All regions" />
      <FilterGroup label="Budget" options={['all', ...BUDGETS]} value={budget} onChange={setBudget} formatAll="All budgets" />
      <FilterGroup label="Travel Style" options={['all', ...TRAVEL_STYLES_ALL]} value={style} onChange={setStyle} formatAll="All styles" />
      <FilterGroup label="Best Season" options={['all', ...SEASON_OPTS]} value={season} onChange={setSeason} formatAll="Any season" />
      {activeCount > 0 && (
        <button onClick={clearAll} className="text-xs tracking-[0.15em] uppercase text-coral-500 hover:text-coral-600 flex items-center gap-1.5 font-semibold">
          <X size={13} /> Clear all filters
        </button>
      )}
    </div>
  );

  return (
    <div className="container-page py-10 lg:py-14">
      {/* Japan pinned banner */}
      <Reveal>
        <Link to="/japan" className="group block relative img-zoom rounded-3xl overflow-hidden h-[200px] lg:h-[240px] mb-10">
          <img src="https://images.pexels.com/photos/31710067/pexels-photo-31710067.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="Japan featured" className="w-full h-full object-cover" loading="lazy" />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-950/85 to-navy-950/30" />
          <div className="absolute inset-0 flex flex-col justify-center px-8">
            <p className="text-coral-300 text-[0.65rem] tracking-[0.25em] uppercase font-semibold mb-2">Signature Destination</p>
            <h2 className="font-display font-extrabold text-white text-2xl lg:text-3xl mb-1">Discover the Magic of Japan</h2>
            <span className="inline-flex items-center gap-1.5 text-white text-sm font-semibold group-hover:gap-2.5 transition-all">Explore Japan <ArrowRight size={15} /></span>
          </div>
        </Link>
      </Reveal>

      <Reveal>
        <div className="mb-8">
          <p className="eyebrow mb-2">Explore Destinations</p>
          <h1 className="font-display font-extrabold text-4xl md:text-5xl text-navy-700">Where will you go?</h1>
          <p className="text-sm text-navy-500/70 mt-2">{filtered.length} destinations{search && ` for "${search}"`}</p>
        </div>
      </Reveal>

      {/* Search + sort bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8 pb-4 border-b border-cloud-200">
        <div className="flex items-center gap-3 w-full lg:max-w-xs">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-300" />
            <input value={search} onChange={(e) => { setSearch(e.target.value); setVisible(6); }} placeholder="Search destinations…" className="w-full pl-9 pr-4 py-2.5 text-sm bg-cloud-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-coral-400/30 text-navy-700" />
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setFiltersOpen(true)} className="lg:hidden inline-flex items-center gap-2 text-xs tracking-[0.15em] uppercase border border-cloud-300 px-4 py-2.5 rounded-xl font-semibold">
            <SlidersHorizontal size={14} /> Filters {activeCount > 0 && `(${activeCount})`}
          </button>
          <select value={sort} onChange={(e) => setSort(e.target.value as SortKey)} className="text-sm bg-cloud-100 border-0 px-3 py-2.5 rounded-xl focus:outline-none focus:ring-2 focus:ring-coral-400/30 text-navy-700">
            <option value="featured">Featured</option>
            <option value="name">Name A–Z</option>
            <option value="budget">Budget: Low to High</option>
          </select>
          <div className="hidden sm:flex items-center border border-cloud-300 rounded-xl overflow-hidden">
            <button onClick={() => setView('grid')} aria-label="Grid view" className={`p-2.5 ${view === 'grid' ? 'bg-navy-700 text-white' : 'text-navy-500'}`}><Grid3x3 size={16} /></button>
            <button onClick={() => setView('list')} aria-label="List view" className={`p-2.5 ${view === 'list' ? 'bg-navy-700 text-white' : 'text-navy-500'}`}><List size={16} /></button>
          </div>
        </div>
      </div>

      <div className="flex gap-10">
        <aside className="hidden lg:block w-60 shrink-0">
          <div className="sticky top-32"><Filters /></div>
        </aside>

        <div className="flex-1 min-w-0">
          {shown.length === 0 ? (
            <div className="text-center py-24">
              <MapPin size={40} className="mx-auto text-cloud-300 mb-4" strokeWidth={1.5} />
              <p className="font-display font-bold text-xl text-navy-700 mb-2">No destinations found</p>
              <p className="text-sm text-navy-500/70 mb-6">Try adjusting your filters or search.</p>
              <button onClick={clearAll} className="btn-outline">Clear filters</button>
            </div>
          ) : view === 'grid' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {shown.map((d, i) => (
                <Link key={d.id} to={`/destinations/${d.slug}`} className="group img-zoom rounded-2xl overflow-hidden bg-white shadow-sm hover:shadow-xl transition-shadow duration-500 animate-fade-up" >
                  <div className="aspect-[4/3] overflow-hidden">
                    <img src={d.image} alt={d.name} className="w-full h-full object-cover" loading="lazy" />
                  </div>
                  <div className="p-5">
                    <div className="flex items-center gap-1.5 text-xs text-ocean-400 mb-1.5"><MapPin size={13} /> {d.country}</div>
                    <h3 className="font-display font-bold text-xl text-navy-700 mb-1.5 group-hover:text-coral-500 transition-colors">{d.name}</h3>
                    <p className="text-sm text-navy-500/80 leading-relaxed line-clamp-2 mb-3">{d.shortDesc}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-navy-500">{d.budget}</span>
                      <span className="inline-flex items-center gap-1 text-sm font-semibold text-coral-500 group-hover:gap-2 transition-all">Explore <ArrowRight size={14} /></span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              {shown.map((d) => (
                <Link key={d.id} to={`/destinations/${d.slug}`} className="group flex gap-5 bg-white rounded-2xl overflow-hidden border border-cloud-200 hover:shadow-lg transition-all duration-300">
                  <div className="img-zoom w-32 sm:w-48 aspect-[4/3] shrink-0">
                    <img src={d.image} alt={d.name} className="w-full h-full object-cover" loading="lazy" />
                  </div>
                  <div className="flex-1 p-5 flex flex-col justify-center">
                    <div className="flex items-center gap-1.5 text-xs text-ocean-400 mb-1"><MapPin size={12} /> {d.country} · {d.region}</div>
                    <h3 className="font-display font-bold text-lg text-navy-700 group-hover:text-coral-500 transition-colors">{d.name}</h3>
                    <p className="text-sm text-navy-500/75 line-clamp-2 mt-1">{d.shortDesc}</p>
                    <div className="flex items-center gap-3 mt-2">
                      <span className="text-xs font-medium text-navy-500">{d.duration}</span>
                      <span className="text-xs text-navy-300">·</span>
                      <span className="text-xs font-medium text-navy-500">{d.budget}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}

          {visible < filtered.length && (
            <div className="text-center mt-12">
              <button onClick={() => setVisible((v) => v + 6)} className="btn-outline">Load More ({filtered.length - visible} more)</button>
            </div>
          )}
        </div>
      </div>

      {filtersOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-navy-950/40 backdrop-blur-sm" onClick={() => setFiltersOpen(false)} />
          <div className="absolute right-0 top-0 bottom-0 w-[85%] max-w-sm bg-cloud-50 p-6 overflow-y-auto animate-slide-in-right">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display font-bold text-xl text-navy-700">Filters</h2>
              <button onClick={() => setFiltersOpen(false)} aria-label="Close"><X size={22} /></button>
            </div>
            <Filters />
            <button onClick={() => setFiltersOpen(false)} className="btn-coral w-full mt-8">Show {filtered.length} results</button>
          </div>
        </div>
      )}
    </div>
  );
}

function FilterGroup({ label, options, value, onChange, formatAll }: { label: string; options: string[]; value: string; onChange: (v: string) => void; formatAll: string }) {
  return (
    <div>
      <h3 className="text-[0.7rem] tracking-[0.15em] uppercase font-semibold text-navy-500 mb-3">{label}</h3>
      <div className="flex flex-col gap-1.5">
        {options.map((opt) => (
          <button
            key={opt}
            onClick={() => onChange(opt)}
            className={`text-sm text-left py-1 transition-colors ${value === opt ? 'text-coral-500 font-semibold' : 'text-navy-700/70 hover:text-navy-700'}`}
          >
            {opt === 'all' ? formatAll : opt}
          </button>
        ))}
      </div>
    </div>
  );
}
