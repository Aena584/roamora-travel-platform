import { Compass, MapPin, Sparkles, Heart, Globe } from 'lucide-react';
import { Link } from '@/router';
import { Reveal } from '@/components/ui';

export function AboutPage() {
  return (
    <div>
      <section className="relative h-[50vh] min-h-[360px] overflow-hidden bg-navy-900 flex items-center">
        <img src="https://images.pexels.com/photos/20385882/pexels-photo-20385882.jpeg?auto=compress&cs=tinysrgb&h=1000&w=1920" alt="Travel landscape" className="absolute inset-0 w-full h-full object-cover opacity-50" />
        <div className="absolute inset-0 bg-gradient-to-r from-navy-950/85 to-navy-950/50" />
        <div className="relative container-page">
          <p className="text-coral-300 text-[0.7rem] tracking-[0.25em] uppercase font-semibold mb-3">Our Story</p>
          <h1 className="font-display font-extrabold text-white text-4xl md:text-6xl max-w-2xl text-balance">We believe travel should feel personal.</h1>
        </div>
      </section>

      <section className="container-page py-16 max-w-3xl">
        <Reveal>
          <p className="text-navy-700/85 text-lg md:text-xl leading-relaxed font-serif-display mb-6">
            ROAMORA was born from a simple frustration: the best travel platforms felt like search engines, not storytellers. They showed you everything and helped you feel nothing.
          </p>
          <p className="text-navy-700/85 text-lg leading-relaxed font-serif-display mb-6">
            We built ROAMORA to be different — a place where discovering a destination feels like turning the page of a book you can't put down. Where curated collections replace endless lists. Where planning a trip is as inspiring as taking one.
          </p>
          <p className="text-navy-700/85 text-lg leading-relaxed font-serif-display">
            From our signature Japan experience to destinations across six continents, every place we feature is chosen with intention. We don't want to show you the world — we want to help you find the part of it that's yours.
          </p>
        </Reveal>
      </section>

      <section className="bg-cloud-100 py-16 bg-grain">
        <div className="container-page grid md:grid-cols-3 gap-6">
          {[
            { icon: Compass, t: 'Curated, not exhaustive', d: 'We feature destinations we believe in, not everything that exists. Quality over quantity, always.' },
            { icon: Sparkles, t: 'Inspiration first', d: 'We design for the moment of discovery — the spark that makes you want to go somewhere new.' },
            { icon: Heart, t: 'Plan at your pace', d: 'Save what inspires you. Build your trip over days or weeks. No pressure, no noise.' },
          ].map((v, i) => (
            <Reveal key={v.t} delay={i * 100}>
              <div className="bg-white rounded-2xl p-7 h-full border border-cloud-200">
                <div className="w-12 h-12 rounded-xl bg-coral-50 flex items-center justify-center mb-4">
                  <v.icon size={22} className="text-coral-500" />
                </div>
                <h3 className="font-display font-bold text-xl text-navy-700 mb-2">{v.t}</h3>
                <p className="text-sm text-navy-500/80 leading-relaxed">{v.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="container-page py-16 text-center max-w-xl mx-auto">
        <Reveal>
          <Globe size={40} className="mx-auto text-coral-400 mb-4" />
          <h2 className="font-display font-extrabold text-3xl text-navy-700 mb-4">The world is yours to explore.</h2>
          <p className="text-navy-500/80 mb-6">Start with Japan — our most loved signature destination — or wander the full collection.</p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link to="/japan" className="btn-coral">Discover Japan</Link>
            <Link to="/destinations" className="btn-outline">Explore Destinations</Link>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
