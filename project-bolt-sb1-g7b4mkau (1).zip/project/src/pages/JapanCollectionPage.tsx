import { ArrowRight, MapPin, Heart, Calendar, Check } from 'lucide-react';
import { Link, useRouter } from '@/router';
import { Reveal } from '@/components/ui';
import { getJapanCollection, JAPAN_COLLECTIONS, ITINERARIES } from '@/data/catalog';
import { useStore } from '@/store/StoreContext';

export function JapanCollectionPage({ id }: { id: string }) {
  const col = getJapanCollection(id);
  const { toggleSave, isSaved } = useStore();
  const { navigate } = useRouter();

  if (!col) {
    return (
      <div className="container-page py-32 text-center">
        <h1 className="font-display font-extrabold text-3xl text-navy-700 mb-4">Collection not found</h1>
        <Link to="/japan" className="btn-coral">Back to Japan</Link>
      </div>
    );
  }

  const saved = isSaved('collection', col.id);
  const relatedItineraries = ITINERARIES.filter((i) => i.destinations.some((d) => d.toLowerCase().includes(col.name.toLowerCase()))).slice(0, 2);
  const otherCollections = JAPAN_COLLECTIONS.filter((c) => c.id !== id).slice(0, 4);

  return (
    <div>
      {/* Hero */}
      <section className="relative h-[60vh] min-h-[440px] overflow-hidden bg-navy-900">
        <img src={col.image} alt={col.name} className="absolute inset-0 w-full h-full object-cover animate-ken-burns" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-950/30 to-navy-950/40" />
        <div className="relative container-page h-full flex flex-col justify-end pb-12">
          <Link to="/japan" className="text-coral-300 text-xs tracking-[0.2em] uppercase font-semibold mb-4 inline-flex items-center gap-1.5">
            ← Back to Japan
          </Link>
          <p className="text-coral-300 text-[0.7rem] tracking-[0.25em] uppercase font-semibold mb-3">{col.tagline}</p>
          <h1 className="font-display font-extrabold text-white text-5xl md:text-6xl mb-4">{col.name}</h1>
          <p className="text-white/85 text-lg max-w-2xl leading-relaxed">{col.desc}</p>
          <div className="flex items-center gap-3 mt-5">
            <button onClick={() => navigate('/itineraries')} className="btn-coral text-sm py-2.5">Plan a trip here</button>
            <button
              onClick={() => toggleSave({ type: 'collection', id: col.id, title: col.name, image: col.image, meta: col.tagline })}
              className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold border transition-colors ${saved ? 'bg-coral-50 text-coral-500 border-coral-200' : 'bg-white/10 text-white border-white/30 hover:bg-white/20'}`}
            >
              <Heart size={15} className={saved ? 'fill-coral-500' : ''} /> {saved ? 'Saved' : 'Save'}
            </button>
          </div>
        </div>
      </section>

      {/* Overview */}
      <section className="container-page py-16 max-w-3xl">
        <Reveal>
          <p className="eyebrow mb-3">Overview</p>
          <p className="text-navy-700/85 text-lg leading-relaxed font-serif-display">{col.desc_long}</p>
          <div className="flex items-center gap-2 mt-6 text-sm text-ocean-400">
            <Calendar size={15} /> <span className="font-medium">Best time: {col.season}</span>
          </div>
        </Reveal>
      </section>

      {/* Highlights */}
      <section className="container-page pb-16">
        <Reveal>
          <h2 className="font-display font-extrabold text-3xl text-navy-700 mb-8">Top Highlights</h2>
        </Reveal>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {col.highlights.map((h, i) => (
            <Reveal key={h} delay={(i % 3) * 80}>
              <div className="bg-white rounded-xl p-5 border border-cloud-200 hover:border-coral-400/30 hover:shadow-md transition-all duration-300 flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-coral-50 flex items-center justify-center shrink-0">
                  <Check size={16} className="text-coral-500" />
                </div>
                <span className="text-sm font-medium text-navy-700 pt-1">{h}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Gallery */}
      {col.gallery.length > 0 && (
        <section className="container-page pb-16">
          <Reveal>
            <h2 className="font-display font-extrabold text-3xl text-navy-700 mb-8">Gallery</h2>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {col.gallery.map((img, i) => (
              <Reveal key={i} delay={(i % 3) * 80}>
                <div className={`img-zoom rounded-2xl overflow-hidden ${i === 0 ? 'md:col-span-2 md:row-span-2 aspect-[16/10]' : 'aspect-[4/3]'}`}>
                  <img src={img} alt={`${col.name} ${i + 1}`} className="w-full h-full object-cover" loading="lazy" />
                </div>
              </Reveal>
            ))}
          </div>
        </section>
      )}

      {/* Related itineraries */}
      {relatedItineraries.length > 0 && (
        <section className="container-page pb-16">
          <Reveal>
            <h2 className="font-display font-extrabold text-3xl text-navy-700 mb-6">Itineraries featuring {col.name}</h2>
          </Reveal>
          <div className="grid sm:grid-cols-2 gap-5">
            {relatedItineraries.map((itin) => (
              <Link key={itin.id} to={`/itineraries/${itin.slug}`} className="group bg-white rounded-2xl p-6 border border-cloud-200 hover:shadow-lg transition-all duration-300">
                <div className="flex items-center gap-2 mb-2">
                  <span className="chip bg-navy-700 text-white border-transparent text-[0.65rem]"><Calendar size={11} /> {itin.duration}</span>
                </div>
                <h3 className="font-display font-bold text-lg text-navy-700 group-hover:text-coral-500 transition-colors">{itin.title}</h3>
                <p className="text-sm text-navy-500/70 mt-1">{itin.destinations.join(' → ')}</p>
                <span className="inline-flex items-center gap-1 text-sm font-semibold text-coral-500 mt-3 group-hover:gap-2 transition-all">View itinerary <ArrowRight size={14} /></span>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Other collections */}
      <section className="bg-navy-700 py-16">
        <div className="container-page">
          <Reveal>
            <h2 className="font-display font-extrabold text-white text-2xl mb-6">More of Japan</h2>
          </Reveal>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {otherCollections.map((c) => (
              <Link key={c.id} to={`/japan/${c.id}`} className="group block relative img-zoom rounded-xl overflow-hidden h-[180px]">
                <img src={c.image} alt={c.name} className="w-full h-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-950/80 to-transparent" />
                <div className="absolute bottom-0 p-4">
                  <h3 className="font-display font-bold text-white text-sm">{c.name}</h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
