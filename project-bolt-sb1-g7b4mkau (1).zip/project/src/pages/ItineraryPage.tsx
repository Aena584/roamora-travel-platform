import { Clock, MapPin, Wallet, Hotel, Heart, Calendar, ArrowRight, Info } from 'lucide-react';
import { Link, useRouter } from '@/router';
import { Reveal } from '@/components/ui';
import { getItinerary, ITINERARIES, JAPAN_COLLECTIONS } from '@/data/catalog';
import { useStore } from '@/store/StoreContext';

export function ItineraryPage({ slug }: { slug: string }) {
  const itin = getItinerary(slug);
  const { toggleSave, isSaved, toggleTrip, isInTrip } = useStore();
  const { navigate } = useRouter();

  if (!itin) {
    return (
      <div className="container-page py-32 text-center">
        <h1 className="font-display font-extrabold text-3xl text-navy-700 mb-4">Itinerary not found</h1>
        <Link to="/itineraries" className="btn-coral">View all itineraries</Link>
      </div>
    );
  }

  const saved = isSaved('itinerary', itin.id);
  const inTrip = isInTrip(itin.id);
  const heroImage = JAPAN_COLLECTIONS.find((c) => c.id === itin.destinations[0]?.toLowerCase().replace(/\s/g, '-'))?.image ?? JAPAN_COLLECTIONS[0].image;
  const others = ITINERARIES.filter((i) => i.slug !== slug).slice(0, 3);

  return (
    <div>
      {/* Hero */}
      <section className="relative h-[50vh] min-h-[380px] overflow-hidden bg-navy-900">
        <img src={heroImage} alt={itin.title} className="absolute inset-0 w-full h-full object-cover animate-ken-burns" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-950/40 to-navy-950/50" />
        <div className="relative container-page h-full flex flex-col justify-end pb-10">
          <Link to="/itineraries" className="text-coral-300 text-xs tracking-[0.2em] uppercase font-semibold mb-3 inline-flex items-center gap-1.5">
            ← All Itineraries
          </Link>
          <div className="flex items-center gap-2 mb-3">
            <span className="chip bg-white/10 text-white border-white/20"><Clock size={11} /> {itin.duration}</span>
            <span className="chip bg-coral-400/90 text-white border-transparent">{itin.style}</span>
          </div>
          <h1 className="font-display font-extrabold text-white text-4xl md:text-5xl mb-3">{itin.title}</h1>
          <p className="text-white/80 flex items-center gap-1.5 text-sm"><MapPin size={14} /> {itin.destinations.join(' → ')}</p>
        </div>
      </section>

      {/* Key info */}
      <section className="container-page py-10">
        <Reveal>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <InfoCard icon={Wallet} label="Estimated Budget" value={itin.budgetEstimate} />
            <InfoCard icon={Clock} label="Duration" value={itin.duration} />
            <InfoCard icon={Hotel} label="Accommodation" value={itin.accommodation} />
            <InfoCard icon={MapPin} label="Destinations" value={`${itin.destinations.length} stops`} />
          </div>
        </Reveal>
      </section>

      {/* Budget notes */}
      <section className="container-page pb-10 max-w-3xl">
        <Reveal>
          <div className="bg-cloud-100 rounded-2xl p-6 border border-cloud-200 flex gap-3">
            <Info size={20} className="text-ocean-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-navy-700 mb-1">About this budget estimate</p>
              <p className="text-sm text-navy-500/80 leading-relaxed">{itin.budgetNotes}</p>
            </div>
          </div>
        </Reveal>
      </section>

      {/* Day-by-day */}
      <section className="container-page pb-12">
        <Reveal>
          <h2 className="font-display font-extrabold text-3xl text-navy-700 mb-8">Day-by-Day Outline</h2>
        </Reveal>
        <div className="relative max-w-3xl">
          <div className="absolute left-[27px] top-2 bottom-2 w-px bg-cloud-200" />
          {itin.days.map((day, i) => (
            <Reveal key={day.day} delay={i * 60}>
              <div className="flex gap-5 pb-8 last:pb-0">
                <div className="shrink-0 w-14 h-14 rounded-full bg-coral-400 text-white font-display font-bold text-lg flex items-center justify-center z-10">
                  {day.day}
                </div>
                <div className="pt-2">
                  <h3 className="font-display font-bold text-lg text-navy-700 mb-1.5">Day {day.day}: {day.title}</h3>
                  <p className="text-sm text-navy-500/80 leading-relaxed">{day.desc}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Actions */}
      <section className="container-page pb-16">
        <Reveal>
          <div className="bg-navy-700 rounded-2xl p-8 text-center">
            <h3 className="font-display font-bold text-white text-xl mb-2">Ready to make this trip yours?</h3>
            <p className="text-cloud-200/70 text-sm mb-5">Save this itinerary to your trip planner or wishlist.</p>
            <div className="flex flex-wrap gap-3 justify-center">
              <button
                onClick={() => toggleTrip(itin.id)}
                className={`inline-flex items-center gap-2 px-6 py-3 rounded-full text-sm font-semibold transition-colors ${inTrip ? 'bg-coral-400 text-white' : 'bg-white text-navy-700 hover:bg-cloud-100'}`}
              >
                <Calendar size={15} /> {inTrip ? 'In your trip planner' : 'Add to trip planner'}
              </button>
              <button
                onClick={() => toggleSave({ type: 'itinerary', id: itin.id, title: itin.title, image: heroImage, meta: itin.duration })}
                className={`inline-flex items-center gap-2 px-6 py-3 rounded-full text-sm font-semibold border transition-colors ${saved ? 'bg-coral-50 text-coral-500 border-coral-200' : 'bg-transparent text-white border-white/30 hover:bg-white/10'}`}
              >
                <Heart size={15} className={saved ? 'fill-coral-500' : ''} /> {saved ? 'Saved to wishlist' : 'Save to wishlist'}
              </button>
            </div>
          </div>
        </Reveal>
      </section>

      {/* Other itineraries */}
      <section className="bg-cloud-100 py-16">
        <div className="container-page">
          <Reveal>
            <h2 className="font-display font-extrabold text-2xl text-navy-700 mb-6">More Japan Itineraries</h2>
          </Reveal>
          <div className="grid sm:grid-cols-3 gap-5">
            {others.map((o) => (
              <Link key={o.id} to={`/itineraries/${o.slug}`} className="group bg-white rounded-2xl p-6 border border-cloud-200 hover:shadow-lg transition-all duration-300">
                <span className="chip bg-navy-700 text-white border-transparent text-[0.65rem] mb-3 inline-flex"><Clock size={11} /> {o.duration}</span>
                <h3 className="font-display font-bold text-lg text-navy-700 group-hover:text-coral-500 transition-colors mb-1">{o.title}</h3>
                <p className="text-xs text-navy-500/70 mb-3">{o.destinations.join(' → ')}</p>
                <span className="inline-flex items-center gap-1 text-sm font-semibold text-coral-500 group-hover:gap-2 transition-all">View <ArrowRight size={13} /></span>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

function InfoCard({ icon: Icon, label, value }: { icon: React.ComponentType<{ size?: number; className?: string }>; label: string; value: string }) {
  return (
    <div className="bg-white rounded-xl p-5 border border-cloud-200">
      <div className="flex items-center gap-2 mb-2">
        <Icon size={16} className="text-coral-500" />
        <span className="text-[0.65rem] tracking-[0.15em] uppercase font-semibold text-navy-500">{label}</span>
      </div>
      <p className="text-sm font-semibold text-navy-700 leading-snug">{value}</p>
    </div>
  );
}

export function ItinerariesListPage() {
  return (
    <div className="container-page py-10 lg:py-14">
      <Reveal>
        <div className="text-center mb-12">
          <p className="eyebrow mb-3">Japan Itineraries</p>
          <h1 className="font-display font-extrabold text-4xl md:text-5xl text-navy-700">Your Japan Journey, Beautifully Planned.</h1>
          <p className="text-navy-500/70 text-sm mt-3 max-w-xl mx-auto">
            Sample itineraries from 5 to 14 days. Budgets are estimates — see each itinerary for assumptions.
          </p>
        </div>
      </Reveal>
      <div className="grid md:grid-cols-2 gap-6">
        {ITINERARIES.map((itin, i) => {
          const heroImage = JAPAN_COLLECTIONS.find((c) => c.id === itin.destinations[0]?.toLowerCase().replace(/\s/g, '-'))?.image ?? JAPAN_COLLECTIONS[0].image;
          return (
            <Reveal key={itin.id} delay={(i % 2) * 100}>
              <Link to={`/itineraries/${itin.slug}`} className="group block bg-white rounded-2xl overflow-hidden border border-cloud-200 hover:shadow-xl transition-shadow duration-500 h-full">
                <div className="img-zoom aspect-[16/9] overflow-hidden">
                  <img src={heroImage} alt={itin.title} className="w-full h-full object-cover" loading="lazy" />
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="chip bg-navy-700 text-white border-transparent text-[0.65rem]"><Clock size={11} /> {itin.duration}</span>
                    <span className="chip bg-coral-50 text-coral-500 border-coral-200 text-[0.65rem]">{itin.style}</span>
                  </div>
                  <h3 className="font-display font-bold text-xl text-navy-700 mb-2 group-hover:text-coral-500 transition-colors">{itin.title}</h3>
                  <p className="text-sm text-navy-500/75 mb-3 flex items-center gap-1.5"><MapPin size={13} className="text-ocean-400" /> {itin.destinations.join(' → ')}</p>
                  <div className="flex items-baseline justify-between pt-3 border-t border-cloud-200">
                    <span className="text-[0.65rem] tracking-[0.15em] uppercase font-semibold text-navy-500">Est. Budget</span>
                    <span className="text-sm font-bold text-navy-700">{itin.budgetEstimate}</span>
                  </div>
                </div>
              </Link>
            </Reveal>
          );
        })}
      </div>
    </div>
  );
}
