import { Heart, MapPin, Calendar, Trash2, ArrowRight } from 'lucide-react';
import { Link } from '@/router';
import { useStore } from '@/store/StoreContext';
import { ITINERARIES } from '@/data/catalog';

function routeFor(type: string, id: string): string {
  if (type === 'destination') return `/destinations/${id}`;
  if (type === 'itinerary') return `/itineraries/${id}`;
  if (type === 'collection') return `/japan/${id}`;
  return '#';
}

export function WishlistPage() {
  const { wishlist, toggleSave } = useStore();

  if (wishlist.length === 0) {
    return (
      <div className="container-page py-24 text-center">
        <Heart size={48} className="mx-auto text-cloud-300 mb-5" strokeWidth={1.5} />
        <h1 className="font-display font-extrabold text-3xl text-navy-700 mb-3">Your wishlist is empty</h1>
        <p className="text-sm text-navy-500/70 mb-8 max-w-sm mx-auto">Save destinations, itineraries, and collections you love by tapping the heart icon. They'll be waiting here.</p>
        <Link to="/destinations" className="btn-coral">Discover Destinations</Link>
      </div>
    );
  }

  return (
    <div className="container-page py-10 lg:py-14">
      <div className="mb-8">
        <p className="eyebrow mb-2">Saved for later</p>
        <h1 className="font-display font-extrabold text-4xl md:text-5xl text-navy-700">Your Wishlist</h1>
        <p className="text-sm text-navy-500/70 mt-2">{wishlist.length} saved item{wishlist.length !== 1 && 's'}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {wishlist.map((item) => (
          <div key={item.type + item.id} className="group bg-white rounded-2xl overflow-hidden border border-cloud-200 hover:shadow-lg transition-shadow duration-300">
            <Link to={routeFor(item.type, item.id)} className="block">
              <div className="img-zoom aspect-[4/3] overflow-hidden">
                <img src={item.image} alt={item.title} className="w-full h-full object-cover" loading="lazy" />
              </div>
            </Link>
            <div className="p-5">
              <div className="flex items-center gap-2 mb-2">
                <span className="chip bg-cloud-100 text-navy-500 border-cloud-200 text-[0.6rem] capitalize">{item.type}</span>
                <span className="text-xs text-ocean-400 flex items-center gap-1">{item.type === 'itinerary' ? <Calendar size={11} /> : <MapPin size={11} />} {item.meta}</span>
              </div>
              <h3 className="font-display font-bold text-lg text-navy-700 mb-3">{item.title}</h3>
              <div className="flex items-center justify-between">
                <Link to={routeFor(item.type, item.id)} className="inline-flex items-center gap-1 text-sm font-semibold text-coral-500 hover:gap-2 transition-all">View <ArrowRight size={13} /></Link>
                <button onClick={() => toggleSave({ type: item.type as 'destination' | 'itinerary' | 'collection', id: item.id, title: item.title, image: item.image, meta: item.meta })} className="text-navy-300 hover:text-coral-500 transition-colors" aria-label="Remove">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function TripsPage() {
  const { tripPlanner, toggleTrip } = useStore();

  if (tripPlanner.length === 0) {
    return (
      <div className="container-page py-24 text-center">
        <Calendar size={48} className="mx-auto text-cloud-300 mb-5" strokeWidth={1.5} />
        <h1 className="font-display font-extrabold text-3xl text-navy-700 mb-3">Your trip planner is empty</h1>
        <p className="text-sm text-navy-500/70 mb-8 max-w-sm mx-auto">Add itineraries to your trip planner to start building your journey.</p>
        <Link to="/itineraries" className="btn-coral">Browse Itineraries</Link>
      </div>
    );
  }

  const trips = ITINERARIES.filter((i) => tripPlanner.includes(i.id));

  return (
    <div className="container-page py-10 lg:py-14">
      <div className="mb-8">
        <p className="eyebrow mb-2">Your journey</p>
        <h1 className="font-display font-extrabold text-4xl md:text-5xl text-navy-700">Trip Planner</h1>
        <p className="text-sm text-navy-500/70 mt-2">{trips.length} itinerary{trips.length !== 1 && 's'} saved</p>
      </div>
      <div className="grid md:grid-cols-2 gap-5">
        {trips.map((itin) => (
          <div key={itin.id} className="bg-white rounded-2xl p-6 border border-cloud-200">
            <div className="flex items-center gap-2 mb-3">
              <span className="chip bg-navy-700 text-white border-transparent text-[0.65rem]"><Calendar size={11} /> {itin.duration}</span>
            </div>
            <h3 className="font-display font-bold text-xl text-navy-700 mb-2">{itin.title}</h3>
            <p className="text-sm text-navy-500/70 mb-4 flex items-center gap-1.5"><MapPin size={13} className="text-ocean-400" /> {itin.destinations.join(' → ')}</p>
            <div className="flex items-center justify-between">
              <Link to={`/itineraries/${itin.slug}`} className="inline-flex items-center gap-1 text-sm font-semibold text-coral-500 hover:gap-2 transition-all">View itinerary <ArrowRight size={13} /></Link>
              <button onClick={() => toggleTrip(itin.id)} className="text-xs font-semibold text-coral-500 hover:text-coral-600">Remove</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function NotFoundPage() {
  return (
    <div className="container-page py-32 text-center">
      <p className="eyebrow mb-3">404</p>
      <h1 className="font-display font-extrabold text-5xl text-navy-700 mb-4">Page not found</h1>
      <p className="text-sm text-navy-500/70 mb-8 max-w-sm mx-auto">The page you're looking for may have moved or no longer exists.</p>
      <div className="flex flex-wrap gap-3 justify-center">
        <Link to="/" className="btn-coral">Back to Home</Link>
        <Link to="/destinations" className="btn-outline">Explore Destinations</Link>
      </div>
    </div>
  );
}
