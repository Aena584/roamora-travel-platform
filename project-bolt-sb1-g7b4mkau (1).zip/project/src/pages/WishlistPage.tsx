import { Heart, ShoppingBag, X } from 'lucide-react';
import { Link } from '@/router';
import { useStore } from '@/store/StoreContext';
import { PRODUCTS } from '@/data/catalog';
import { ProductCard } from '@/components/ProductCard';
import { StarRating, Price } from '@/components/ui';

export function WishlistPage() {
  const { wishlist, toggleWishlist, addToCart, notify } = useStore();
  const items = PRODUCTS.filter((p) => wishlist.includes(p.id));

  if (items.length === 0) {
    return (
      <div className="container-page py-24 text-center">
        <Heart size={48} className="mx-auto text-ivory-400 mb-5" strokeWidth={1} />
        <h1 className="font-serif text-3xl text-espresso-900 mb-3">Your wishlist is empty</h1>
        <p className="text-sm text-espresso-700/70 mb-8 max-w-sm mx-auto">
          Save the pieces you love by tapping the heart on any product. They will be waiting for you here.
        </p>
        <Link to="/shop" className="btn-primary inline-flex">Discover Products</Link>
      </div>
    );
  }

  return (
    <div className="container-page py-10 lg:py-14">
      <div className="flex items-end justify-between mb-8">
        <div>
          <p className="eyebrow mb-2">Saved for later</p>
          <h1 className="font-serif text-4xl md:text-5xl text-espresso-900">Your Wishlist</h1>
          <p className="text-sm text-espresso-700/70 mt-2">{items.length} item{items.length !== 1 && 's'}</p>
        </div>
      </div>

      <div className="flex flex-col divide-y divide-ivory-200 border-y border-ivory-200">
        {items.map((p) => (
          <div key={p.id} className="py-6 flex flex-col sm:flex-row gap-5">
            <Link to={`/product/${p.slug}`} className="shrink-0">
              <div className="img-zoom w-full sm:w-28 aspect-[3/4] rounded-sm overflow-hidden bg-ivory-100">
                <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover" />
              </div>
            </Link>
            <div className="flex-1 flex flex-col">
              <p className="text-[0.65rem] tracking-[0.2em] uppercase text-espresso-700/60">{p.collection}</p>
              <Link to={`/product/${p.slug}`} className="font-serif text-xl text-espresso-900 hover:text-gold-600">{p.name}</Link>
              <StarRating rating={p.rating} count={p.reviewCount} />
              <Price price={p.price} originalPrice={p.originalPrice} className="text-espresso-900 font-medium mt-2" />
            </div>
            <div className="flex sm:flex-col gap-2 sm:justify-end">
              <button
                onClick={() => { addToCart(p, p.shades?.[0]?.name, 1); }}
                className="inline-flex items-center justify-center gap-2 bg-espresso-900 text-ivory-50 px-5 py-2.5 text-xs tracking-[0.15em] uppercase hover:bg-espresso-800 transition-colors"
              >
                <ShoppingBag size={14} /> Add to bag
              </button>
              <button
                onClick={() => toggleWishlist(p.id)}
                className="inline-flex items-center justify-center gap-2 border border-ivory-300 text-espresso-700 px-5 py-2.5 text-xs tracking-[0.15em] uppercase hover:border-blush-600 hover:text-blush-600 transition-colors"
              >
                <X size={14} /> Remove
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
