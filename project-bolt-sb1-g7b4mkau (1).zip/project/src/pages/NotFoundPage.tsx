import { Link } from '@/router';

export function NotFoundPage() {
  return (
    <div className="container-page py-32 text-center">
      <p className="eyebrow mb-3">404</p>
      <h1 className="font-serif text-5xl text-espresso-900 mb-4">Page not found</h1>
      <p className="text-sm text-espresso-700/70 mb-8 max-w-sm mx-auto">
        The page you are looking for may have moved or no longer exists.
      </p>
      <div className="flex flex-wrap gap-3 justify-center">
        <Link to="/" className="btn-primary">Back to Home</Link>
        <Link to="/shop" className="btn-secondary">Browse Shop</Link>
      </div>
    </div>
  );
}
