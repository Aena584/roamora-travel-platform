import { useState } from 'react';
import { MapPin, Clock, Wallet, Calendar, Train, Heart, ArrowRight, Check, Lightbulb } from 'lucide-react';
import { Link, useRouter } from '@/router';
import { Reveal } from '@/components/ui';
import { getDestination, DESTINATIONS } from '@/data/catalog';
import { useStore } from '@/store/StoreContext';

export function DestinationDetailPage({ slug }: { slug: string }) {
  const dest = getDestination(slug);
  const { toggleSave, isSaved } = useStore();
  const { navigate } = useRouter();
  const [activeImg, setActiveImg] = useState(0);

  if (!dest) {
    return (
      <div className="container-page py-32 text-center">
        <h1 className="font-display font-extrabold text-3xl text-navy-700 mb-4">Destination not found</h1>
        <Link to="/destinations" className="btn-coral">Explore destinations</Link>
      </div>
    );
  }

  const saved = isSaved('destination', dest.id);
  const gallery = [dest.image, ...dest.gallery];
  const related = DESTINATIONS.filter((d) => d.slug !== slug && d.region === dest.region).slice(0, 3);
  const isJapan = dest.slug === 'japan';

  const facts = [
    { icon: MapPin, label: 'Region', value: `${dest.country}, ${dest.region}` },
    { icon: Clock, label: 'Suggested Duration', value: dest.duration },
    { icon: Wallet, label: 'Budget Level', value: dest.budget },
    { icon: Calendar, label: 'Best Time to Visit', value: 'See below' },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="relative h-[65vh] min-h-[480px] overflow-hidden bg-navy-900">
        <img src={dest.image} alt={dest.name} className="absolute inset-0 w-full h-full object-cover animate-ken-burns" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-950/30 to-navy-950/40" />
        <div className="relative container-page h-full flex flex-col justify-end pb-10">
          <Link to="/destinations" className="text-coral-300 text-xs tracking-[0.2em] uppercase font-semibold mb-3 inline-flex items-center gap-1.5">← All Destinations</Link>
          <p className="text-coral-300 text-[0.7rem] tracking-[0.25em] uppercase font-semibold mb-2">{dest.country}</p>
          <h1 className="font-display font-extrabold text-white text-5xl md:text-6xl lg:text-7xl mb-4">{dest.name}</h1>
          <p className="text-white/85 text-lg max-w-2xl leading-relaxed mb-5">{dest.shortDesc}</p>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => toggleSave({ type: 'destination', id: dest.id, title: dest.name, image: dest.image, meta: dest.country })}
              className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold transition-colors ${saved ? 'bg-coral-50 text-coral-500 border border-coral-200' : 'bg-white/10 text-white border border-white/30 hover:bg-white/20 backdrop-blur-md'}`}
            >
              <Heart size={15} className={saved ? 'fill-coral-500' : ''} /> {saved ? 'Saved' : 'Save to wishlist'}
            </button>
            {isJapan && <Link to="/japan" className="btn-coral text-sm py-2.5">Explore Japan Hub <ArrowRight size={14} /></Link>}
          </div>
        </div>
      </section>

      {/* Facts strip */}
      <section className="border-b border-cloud-200 bg-white">
        <div className="container-page py-6 grid grid-cols-2 lg:grid-cols-4 gap-4">
          {facts.map((f) => (
            <div key={f.label} className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-coral-50 flex items-center justify-center shrink-0">
                <f.icon size={18} className="text-coral-500" />
              </div>
              <div>
                <p className="text-[0.65rem] tracking-[0.15em] uppercase font-semibold text-navy-500">{f.label}</p>
                <p className="text-sm font-semibold text-navy-700 leading-snug">{f.value}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Overview */}
      <section className="container-page py-14 max-w-3xl">
        <Reveal>
          <p className="eyebrow mb-3">Overview</p>
          <p className="text-navy-700/85 text-lg leading-relaxed font-serif-display">{dest.overview}</p>
        </Reveal>
      </section>

      {/* Gallery */}
      <section className="container-page pb-14">
        <Reveal>
          <h2 className="font-display font-extrabold text-3xl text-navy-700 mb-6">Gallery</h2>
        </Reveal>
        <div className="flex gap-4 flex-col lg:flex-row">
          <div className="img-zoom rounded-2xl overflow-hidden lg:flex-1 aspect-[16/10]">
            <img src={gallery[activeImg]} alt={`${dest.name} ${activeImg + 1}`} className="w-full h-full object-cover" />
          </div>
          <div className="flex lg:flex-col gap-3 lg:w-40">
            {gallery.slice(0, 4).map((img, i) => (
              <button key={i} onClick={() => setActiveImg(i)} className={`img-zoom rounded-xl overflow-hidden aspect-[4/3] lg:aspect-[16/10] flex-1 border-2 transition-colors ${activeImg === i ? 'border-coral-400' : 'border-transparent'}`}>
                <img src={img} alt={`${dest.name} thumbnail ${i + 1}`} className="w-full h-full object-cover" loading="lazy" />
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Top Attractions */}
      <section className="bg-cloud-100 py-14 bg-grain">
        <div className="container-page">
          <Reveal>
            <h2 className="font-display font-extrabold text-3xl text-navy-700 mb-8">Top Attractions</h2>
          </Reveal>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {dest.attractions.map((a, i) => (
              <Reveal key={a.name} delay={(i % 3) * 80}>
                <div className="bg-white rounded-2xl overflow-hidden border border-cloud-200 hover:shadow-lg transition-shadow duration-300 h-full">
                  {a.image && (
                    <div className="img-zoom aspect-[4/3] overflow-hidden">
                      <img src={a.image} alt={a.name} className="w-full h-full object-cover" loading="lazy" />
                    </div>
                  )}
                  <div className="p-5">
                    <h3 className="font-display font-bold text-lg text-navy-700 mb-2">{a.name}</h3>
                    <p className="text-sm text-navy-500/80 leading-relaxed">{a.desc}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Activities + Info grid */}
      <section className="container-page py-14 grid lg:grid-cols-2 gap-10">
        {/* Activities */}
        <Reveal>
          <div>
            <h2 className="font-display font-extrabold text-2xl text-navy-700 mb-5">Recommended Activities</h2>
            <div className="space-y-2.5">
              {dest.activities.map((a) => (
                <div key={a} className="flex items-start gap-3 bg-white rounded-xl p-3.5 border border-cloud-200">
                  <div className="w-6 h-6 rounded-lg bg-coral-50 flex items-center justify-center shrink-0">
                    <Check size={14} className="text-coral-500" />
                  </div>
                  <span className="text-sm text-navy-700 pt-0.5">{a}</span>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        {/* Practical info */}
        <Reveal delay={100}>
          <div className="space-y-6">
            <InfoBlock icon={Calendar} title="Best Time to Visit" text={dest.bestTime} />
            <InfoBlock icon={Lightbulb} title="Culture & Etiquette" text={dest.cultureEtiquette} />
            <InfoBlock icon={Train} title="Transportation" text={dest.transportation} />
          </div>
        </Reveal>
      </section>

      {/* Related */}
      {related.length > 0 && (
        <section className="bg-navy-700 py-14">
          <div className="container-page">
            <Reveal>
              <h2 className="font-display font-extrabold text-white text-2xl mb-6">More in {dest.region}</h2>
            </Reveal>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              {related.map((d) => (
                <Link key={d.id} to={`/destinations/${d.slug}`} className="group block relative img-zoom rounded-2xl overflow-hidden h-[220px]">
                  <img src={d.image} alt={d.name} className="w-full h-full object-cover" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-950/85 to-transparent" />
                  <div className="absolute bottom-0 p-5">
                    <p className="text-coral-300 text-[0.6rem] tracking-[0.2em] uppercase font-semibold mb-1">{d.country}</p>
                    <h3 className="font-display font-bold text-white text-xl group-hover:text-coral-300 transition-colors">{d.name}</h3>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}

function InfoBlock({ icon: Icon, title, text }: { icon: React.ComponentType<{ size?: number; className?: string }>; title: string; text: string }) {
  return (
    <div className="bg-white rounded-2xl p-6 border border-cloud-200">
      <div className="flex items-center gap-2 mb-3">
        <Icon size={18} className="text-coral-500" />
        <h3 className="font-display font-bold text-lg text-navy-700">{title}</h3>
      </div>
      <p className="text-sm text-navy-500/80 leading-relaxed">{text}</p>
    </div>
  );
}
