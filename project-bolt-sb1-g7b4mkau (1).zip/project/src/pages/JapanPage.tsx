import { useState, useRef } from 'react';
import { ArrowRight, ArrowLeft, Compass, Calendar, Wallet, Crown, UtensilsCrossed, Landmark, Mountain, Sparkles, Users, Clock, MapPin } from 'lucide-react';
import { Link, useRouter } from '@/router';
import { Reveal } from '@/components/ui';
import { JAPAN_COLLECTIONS, JAPAN_TRAVEL_STYLES, SEASONS, ITINERARIES, type TravelStyle } from '@/data/catalog';
import { useStore } from '@/store/StoreContext';

const STYLE_ICONS: Record<string, React.ComponentType<{ size?: number; className?: string }>> = {
  Compass, Wallet, Crown, UtensilsCrossed, Landmark, Mountain, Sparkles, Users,
};

export function JapanPage() {
  const carouselRef = useRef<HTMLDivElement>(null);
  const { navigate } = useRouter();

  const scrollCarousel = (dir: 1 | -1) => {
    carouselRef.current?.scrollBy({ left: dir * 340, behavior: 'smooth' });
  };

  return (
    <div>
      {/* HERO */}
      <section className="relative min-h-[90vh] flex items-end overflow-hidden bg-navy-900">
        <img
          src="https://images.pexels.com/photos/35072452/pexels-photo-35072452.jpeg?auto=compress&cs=tinysrgb&h=1400&w=2400"
          alt="Tokyo cityscape at night"
          className="absolute inset-0 w-full h-full object-cover animate-ken-burns"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-950/30 to-navy-950/50" />
        <div className="relative container-page pb-16 pt-32">
          <div className="max-w-2xl animate-fade-up">
            <p className="text-coral-300 text-[0.7rem] tracking-[0.25em] uppercase font-semibold mb-4">Signature Destination</p>
            <h1 className="font-display font-extrabold text-white text-5xl md:text-6xl lg:text-7xl leading-[1.05] mb-5 text-balance">
              Discover the Magic of Japan.
            </h1>
            <p className="text-white/85 text-lg md:text-xl leading-relaxed max-w-lg mb-7">
              From Tokyo's electric energy to Kyoto's timeless traditions, experience a country where ancient culture and modern life meet.
            </p>
            <div className="flex flex-wrap gap-3">
              <a href="#collections" className="btn-coral">Explore Japan</a>
              <a href="#itineraries" className="btn-ghost-light"><Calendar size={16} /> Plan Your Japan Trip</a>
            </div>
          </div>
        </div>
      </section>

      {/* INTRO BAND */}
      <section className="container-page py-16 max-w-3xl text-center">
        <Reveal>
          <p className="eyebrow mb-3">Why Japan</p>
          <p className="text-navy-700/85 text-lg md:text-xl leading-relaxed font-serif-display">
            Japan is a country of living contrasts — where bullet trains glide past centuries-old temples, where the quiet of a bamboo grove sits minutes from a neon district, and where every season rewrites the landscape in a new palette.
          </p>
        </Reveal>
      </section>

      {/* DESTINATION COLLECTIONS */}
      <section id="collections" className="container-page pb-20">
        <Reveal>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
            <div>
              <p className="eyebrow mb-2">Destination Collections</p>
              <h2 className="font-display font-extrabold text-4xl md:text-5xl text-navy-700">Explore Japan, region by region.</h2>
            </div>
            <p className="text-sm text-navy-500/70 max-w-sm">Eight curated collections, each with its own mood — from city energy to island escape.</p>
          </div>
        </Reveal>

        {/* Featured first two large */}
        <div className="grid md:grid-cols-2 gap-5 mb-5">
          {JAPAN_COLLECTIONS.slice(0, 2).map((col, i) => (
            <Reveal key={col.id} delay={i * 100}>
              <Link to={`/japan/${col.id}`} className="group block relative img-zoom rounded-3xl overflow-hidden h-[380px] lg:h-[440px]">
                <img src={col.image} alt={col.name} className="w-full h-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-950/85 via-navy-950/20 to-transparent" />
                <div className="absolute bottom-0 inset-x-0 p-7">
                  <p className="text-coral-300 text-[0.65rem] tracking-[0.2em] uppercase font-semibold mb-2">{col.tagline}</p>
                  <h3 className="font-display font-extrabold text-white text-3xl lg:text-4xl mb-2">{col.name}</h3>
                  <p className="text-white/75 text-sm max-w-md mb-3 line-clamp-2">{col.desc}</p>
                  <span className="inline-flex items-center gap-1.5 text-white text-sm font-semibold group-hover:gap-2.5 transition-all">
                    Explore collection <ArrowRight size={15} />
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>

        {/* Rest in grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {JAPAN_COLLECTIONS.slice(2).map((col, i) => (
            <Reveal key={col.id} delay={(i % 3) * 80}>
              <Link to={`/japan/${col.id}`} className="group block relative img-zoom rounded-2xl overflow-hidden h-[300px]">
                <img src={col.image} alt={col.name} className="w-full h-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-950/85 via-transparent to-transparent" />
                <div className="absolute bottom-0 inset-x-0 p-5">
                  <p className="text-coral-300 text-[0.6rem] tracking-[0.2em] uppercase font-semibold mb-1">{col.tagline}</p>
                  <h3 className="font-display font-bold text-white text-xl mb-1">{col.name}</h3>
                  <span className="inline-flex items-center gap-1 text-white/80 text-xs font-medium group-hover:gap-2 transition-all">
                    Explore <ArrowRight size={12} />
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* SEASONAL JAPAN */}
      <section className="bg-navy-700 py-20">
        <div className="container-page">
          <Reveal>
            <div className="text-center mb-12">
              <p className="eyebrow text-coral-400 mb-2">Seasonal Japan</p>
              <h2 className="font-display font-extrabold text-white text-4xl md:text-5xl">Four seasons, four Japans.</h2>
              <p className="text-cloud-200/70 text-sm mt-3 max-w-xl mx-auto">
                Seasonal conditions vary by region and year. Cherry blossoms and autumn foliage appear at different times depending on location — plan ahead and check forecasts.
              </p>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {SEASONS.map((s, i) => (
              <Reveal key={s.season} delay={i * 90}>
                <div className="group rounded-2xl overflow-hidden bg-navy-800 h-full">
                  <div className="img-zoom aspect-[4/3] overflow-hidden">
                    <img src={s.image} alt={`${s.season} in Japan`} className="w-full h-full object-cover" loading="lazy" />
                  </div>
                  <div className="p-5">
                    <span className="chip bg-coral-400/20 text-coral-300 border-coral-400/30 mb-3">{s.season}</span>
                    <h3 className="font-display font-bold text-white text-lg mb-2">{s.title}</h3>
                    <p className="text-cloud-200/70 text-xs leading-relaxed mb-3">{s.desc}</p>
                    <ul className="space-y-1">
                      {s.recommendations.map((r) => (
                        <li key={r} className="text-xs text-cloud-200/60 flex items-start gap-1.5">
                          <span className="text-coral-400 mt-0.5">·</span> {r}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* TRAVEL STYLES */}
      <section id="travel-styles" className="container-page py-20">
        <Reveal>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
            <div>
              <p className="eyebrow mb-2">Travel Styles</p>
              <h2 className="font-display font-extrabold text-4xl md:text-5xl text-navy-700">Find your way to travel Japan.</h2>
            </div>
            <div className="flex gap-2">
              <button onClick={() => scrollCarousel(-1)} aria-label="Previous" className="w-10 h-10 border border-cloud-300 rounded-full flex items-center justify-center hover:bg-navy-700 hover:text-white hover:border-navy-700 transition-colors">
                <ArrowLeft size={16} />
              </button>
              <button onClick={() => scrollCarousel(1)} aria-label="Next" className="w-10 h-10 border border-cloud-300 rounded-full flex items-center justify-center hover:bg-navy-700 hover:text-white hover:border-navy-700 transition-colors">
                <ArrowRight size={16} />
              </button>
            </div>
          </div>
        </Reveal>
        <div ref={carouselRef} className="flex gap-4 overflow-x-auto scrollbar-hide snap-x snap-mandatory pb-2 -mx-5 px-5">
          {JAPAN_TRAVEL_STYLES.map((style, i) => {
            const Icon = STYLE_ICONS[style.icon] ?? Compass;
            return (
              <button
                key={style.id}
                onClick={() => navigate('/itineraries')}
                className="snap-start shrink-0 w-[280px] text-left group"
              >
                <div className="bg-white rounded-2xl p-6 border border-cloud-200 hover:border-coral-400/40 hover:shadow-lg transition-all duration-300 h-full">
                  <div className="w-12 h-12 rounded-xl bg-coral-50 flex items-center justify-center mb-4 group-hover:bg-coral-400 transition-colors">
                    <Icon size={22} className="text-coral-500 group-hover:text-white transition-colors" />
                  </div>
                  <h3 className="font-display font-bold text-lg text-navy-700 mb-2">{style.title}</h3>
                  <p className="text-sm text-navy-500/75 leading-relaxed mb-4">{style.desc}</p>
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-coral-500 group-hover:gap-2 transition-all">
                    Explore itineraries <ArrowRight size={12} />
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* ITINERARY PLANNER */}
      <section id="itineraries" className="bg-cloud-100 py-20 bg-grain">
        <div className="container-page">
          <Reveal>
            <div className="text-center mb-12">
              <p className="eyebrow mb-2">Itinerary Planner</p>
              <h2 className="font-display font-extrabold text-4xl md:text-5xl text-navy-700">Your Japan Journey, Beautifully Planned.</h2>
              <p className="text-navy-500/70 text-sm mt-3 max-w-xl mx-auto">
                Sample itineraries to inspire your trip. Budgets are estimates — see each itinerary for assumptions and notes.
              </p>
            </div>
          </Reveal>
          <div className="grid md:grid-cols-2 gap-5">
            {ITINERARIES.map((itin, i) => (
              <Reveal key={itin.id} delay={(i % 2) * 100}>
                <div className="bg-white rounded-2xl overflow-hidden border border-cloud-200 hover:shadow-xl transition-shadow duration-500 h-full flex flex-col">
                  <div className="img-zoom aspect-[16/9] overflow-hidden">
                    <img src={JAPAN_COLLECTIONS.find((c) => c.id === itin.destinations[0]?.toLowerCase().replace(/\s/g, '-'))?.image ?? JAPAN_COLLECTIONS[0].image} alt={itin.title} className="w-full h-full object-cover" loading="lazy" />
                  </div>
                  <div className="p-6 flex-1 flex flex-col">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="chip bg-navy-700 text-white border-transparent text-[0.65rem]"><Clock size={11} /> {itin.duration}</span>
                      <span className="chip bg-coral-50 text-coral-500 border-coral-200 text-[0.65rem]">{itin.style}</span>
                    </div>
                    <h3 className="font-display font-bold text-xl text-navy-700 mb-2">{itin.title}</h3>
                    <p className="text-sm text-navy-500/75 mb-3 flex items-center gap-1.5"><MapPin size={13} className="text-ocean-400" /> {itin.destinations.join(' → ')}</p>
                    <div className="flex items-baseline justify-between mb-4 pt-3 border-t border-cloud-200">
                      <span className="text-[0.65rem] tracking-[0.15em] uppercase font-semibold text-navy-500">Est. Budget</span>
                      <span className="text-sm font-bold text-navy-700">{itin.budgetEstimate}</span>
                    </div>
                    <div className="mt-auto flex gap-2">
                      <Link to={`/itineraries/${itin.slug}`} className="btn-coral flex-1 text-sm py-2.5">View Itinerary</Link>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
