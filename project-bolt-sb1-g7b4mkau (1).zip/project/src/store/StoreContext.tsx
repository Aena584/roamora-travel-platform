import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';

type SaveType = 'destination' | 'itinerary' | 'collection';
interface SavedItem {
  type: SaveType;
  id: string;
  title: string;
  image: string;
  meta: string;
}

interface StoreState {
  wishlist: SavedItem[];
  tripPlanner: string[];
  toggleSave: (item: SavedItem) => void;
  isSaved: (type: SaveType, id: string) => boolean;
  toggleTrip: (id: string) => void;
  isInTrip: (id: string) => boolean;
  toasts: { id: number; message: string }[];
  notify: (message: string) => void;
  dismissToast: (id: number) => void;
}

const StoreContext = createContext<StoreState | null>(null);

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [wishlist, setWishlist] = useState<SavedItem[]>(() => load('roamora-wishlist', []));
  const [tripPlanner, setTripPlanner] = useState<string[]>(() => load('roamora-trips', []));
  const [toasts, setToasts] = useState<{ id: number; message: string }[]>([]);

  useEffect(() => { localStorage.setItem('roamora-wishlist', JSON.stringify(wishlist)); }, [wishlist]);
  useEffect(() => { localStorage.setItem('roamora-trips', JSON.stringify(tripPlanner)); }, [tripPlanner]);

  const notify = useCallback((message: string) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, message }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);
  const dismissToast = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), []);

  const toggleSave = useCallback((item: SavedItem) => {
    setWishlist((prev) => {
      const exists = prev.find((i) => i.type === item.type && i.id === item.id);
      if (exists) {
        notify('Removed from wishlist');
        return prev.filter((i) => !(i.type === item.type && i.id === item.id));
      }
      notify('Saved to wishlist');
      return [...prev, item];
    });
  }, [notify]);

  const isSaved = useCallback((type: SaveType, id: string) => wishlist.some((i) => i.type === type && i.id === id), [wishlist]);

  const toggleTrip = useCallback((id: string) => {
    setTripPlanner((prev) => {
      if (prev.includes(id)) {
        notify('Removed from trip planner');
        return prev.filter((x) => x !== id);
      }
      notify('Added to your trip planner');
      return [...prev, id];
    });
  }, [notify]);

  const isInTrip = useCallback((id: string) => tripPlanner.includes(id), [tripPlanner]);

  const value: StoreState = { wishlist, tripPlanner, toggleSave, isSaved, toggleTrip, isInTrip, toasts, notify, dismissToast };
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}
