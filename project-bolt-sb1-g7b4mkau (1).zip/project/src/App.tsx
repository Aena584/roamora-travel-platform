import { StoreProvider } from '@/store/StoreContext';
import { useRouter } from '@/router';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Toasts } from '@/components/Toasts';
import { HomePage } from '@/pages/HomePage';
import { JapanPage } from '@/pages/JapanPage';
import { JapanCollectionPage } from '@/pages/JapanCollectionPage';
import { ItineraryPage, ItinerariesListPage } from '@/pages/ItineraryPage';
import { DestinationsPage } from '@/pages/DestinationsPage';
import { DestinationDetailPage } from '@/pages/DestinationDetailPage';
import { AboutPage } from '@/pages/AboutPage';
import { WishlistPage, TripsPage, NotFoundPage } from '@/pages/WishlistPages';

function Router() {
  const { route } = useRouter();
  const { path } = route;
  const parts = path.split('/').filter(Boolean);

  if (path === '/' || path === '') return <HomePage />;
  if (path === '/japan') return <JapanPage />;
  if (path === '/destinations') return <DestinationsPage />;
  if (path === '/itineraries') return <ItinerariesListPage />;
  if (path === '/about') return <AboutPage />;
  if (path === '/wishlist') return <WishlistPage />;
  if (path === '/trips') return <TripsPage />;
  if (parts[0] === 'japan' && parts[1]) return <JapanCollectionPage id={parts[1]} />;
  if (parts[0] === 'itineraries' && parts[1]) return <ItineraryPage slug={parts[1]} />;
  if (parts[0] === 'destinations' && parts[1]) return <DestinationDetailPage slug={parts[1]} />;

  return <NotFoundPage />;
}

export default function App() {
  return (
    <StoreProvider>
      <div className="min-h-screen flex flex-col bg-cloud-50">
        <Header />
        <main className="flex-1">
          <Router />
        </main>
        <Footer />
        <Toasts />
      </div>
    </StoreProvider>
  );
}
