import { useEffect, useState } from 'react';
import { Menu, X, Search, Heart, MapPin, Globe } from 'lucide-react';
import { Link, useRouter } from '@/router';
import { useStore } from '@/store/StoreContext';

const NAV = [
  { label: 'Home', to: '/' },
  { label: 'Explore Destinations', to: '/destinations' },
  { label: 'Discover Japan', to: '/japan' },
  { label: 'Itineraries', to: '/itineraries' },
  { label: 'About', to: '/about' },
];

export function Header() {
  const { wishlist, tripPlanner } = useStore();
  const { navigate, route } = useRouter();
  const [scrolled, setScrolled] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchVal, setSearchVal] = useState('');

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setDrawerOpen(false);
    setSearchOpen(false);
  }, [route.path]);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchVal.trim()) {
      navigate(`/destinations?q=${encodeURIComponent(searchVal.trim())}`);
      setSearchOpen(false);
      setSearchVal('');
    }
  };

  const isHome = route.path === '/' || route.path === '';

  return (
    <header className={`sticky top-0 z-40 transition-all duration-300 ${scrolled || !isHome ? 'bg-cloud-50/95 backdrop-blur-md shadow-sm' : 'bg-transparent'}`}>
      <div className="container-page flex items-center justify-between h-16 lg:h-20">
        <button className="lg:hidden text-navy-700" onClick={() => setDrawerOpen(true)} aria-label="Open menu">
          <Menu size={22} />
        </button>

        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium">
          {NAV.slice(0, 3).map((n) => (
            <Link key={n.label} to={n.to} className={`link-underline ${scrolled || !isHome ? 'text-navy-700' : 'text-white'}`}>{n.label}</Link>
          ))}
        </nav>

        <Link to="/" className="flex items-center gap-2.5 absolute left-1/2 -translate-x-1/2">
          <div className="w-8 h-8 rounded-lg bg-coral-400 flex items-center justify-center">
            <MapPin size={16} className="text-white" strokeWidth={2.5} />
          </div>
          <span className={`font-display font-extrabold text-xl tracking-tightest ${scrolled || !isHome ? 'text-navy-700' : 'text-white'}`}>ROAMORA</span>
        </Link>

        <div className="flex items-center gap-4 lg:gap-5">
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium">
            {NAV.slice(3).map((n) => (
              <Link key={n.label} to={n.to} className={`link-underline ${scrolled || !isHome ? 'text-navy-700' : 'text-white'}`}>{n.label}</Link>
            ))}
          </nav>
          <button onClick={() => setSearchOpen((s) => !s)} aria-label="Search" className={`${scrolled || !isHome ? 'text-navy-700' : 'text-white'} hover:text-coral-400 transition-colors`}>
            <Search size={20} />
          </button>
          <Link to="/wishlist" aria-label="Wishlist" className={`relative hover:text-coral-400 transition-colors ${scrolled || !isHome ? 'text-navy-700' : 'text-white'}`}>
            <Heart size={20} />
            {wishlist.length > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-coral-400 text-white text-[0.55rem] font-bold w-4 h-4 rounded-full flex items-center justify-center">{wishlist.length}</span>
            )}
          </Link>
          <Link to="/trips" aria-label="Trip planner" className={`hidden sm:block relative hover:text-coral-400 transition-colors ${scrolled || !isHome ? 'text-navy-700' : 'text-white'}`}>
            <Globe size={20} />
            {tripPlanner.length > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-navy-700 text-white text-[0.55rem] font-bold w-4 h-4 rounded-full flex items-center justify-center">{tripPlanner.length}</span>
            )}
          </Link>
        </div>
      </div>

      {searchOpen && (
        <div className="border-t border-cloud-200 bg-cloud-50 animate-fade-down">
          <form onSubmit={submitSearch} className="container-page py-4 flex items-center gap-3">
            <Search size={18} className="text-navy-300" />
            <input autoFocus value={searchVal} onChange={(e) => setSearchVal(e.target.value)} placeholder="Search destinations, countries, regions…" className="flex-1 bg-transparent outline-none text-sm text-navy-700 placeholder:text-navy-300/50" />
            <button type="submit" className="text-xs font-semibold text-coral-500 uppercase tracking-wider">Search</button>
            <button type="button" onClick={() => setSearchOpen(false)} aria-label="Close"><X size={18} /></button>
          </form>
        </div>
      )}

      {drawerOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-navy-950/50 backdrop-blur-sm animate-fade-in" onClick={() => setDrawerOpen(false)} />
          <div className="absolute left-0 top-0 bottom-0 w-[82%] max-w-sm bg-cloud-50 p-6 animate-slide-in-right flex flex-col">
            <div className="flex items-center justify-between mb-8">
              <span className="font-display font-extrabold text-xl text-navy-700">ROAMORA</span>
              <button onClick={() => setDrawerOpen(false)} aria-label="Close"><X size={22} /></button>
            </div>
            <nav className="flex flex-col gap-4 text-base font-medium text-navy-700">
              {NAV.map((n) => (
                <Link key={n.label} to={n.to} className="hover:text-coral-500 transition-colors">{n.label}</Link>
              ))}
              <Link to="/wishlist" className="hover:text-coral-500 transition-colors">Wishlist</Link>
              <Link to="/trips" className="hover:text-coral-500 transition-colors">Trip Planner</Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}
