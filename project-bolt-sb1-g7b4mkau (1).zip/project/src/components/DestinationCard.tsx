import { ArrowRight, MapPin } from 'lucide-react';
import { Link } from '@/router';
import type { Destination } from '@/data/catalog';

export function DestinationCard({ destination, large = false, index = 0 }: { destination: Destination; large?: boolean; index?: number }) {
  if (large) {
    return (
      <article className="group relative img-zoom rounded-3xl overflow-hidden h-[420px] lg:h-[520px] animate-fade-up" style={{ animationDelay: `${index * 60}ms` }}>
        <Link to={`/destinations/${destination.slug}`} className="block w-full h-full">
          <img src={destination.image} alt={destination.name} className="w-full h-full object-cover" loading="lazy" />
          <div className="absolute inset-0 bg-gradient-to-t from-navy-950/85 via-navy-950/25 to-transparent" />
          <div className="absolute bottom-0 inset-x-0 p-7 lg:p-10">
            <span className="chip bg-coral-400/90 text-white border-transparent mb-4">Featured</span>
            <h3 className="font-display font-extrabold text-3xl lg:text-5xl text-white mb-2">{destination.name}</h3>
            <p className="text-white/80 text-sm lg:text-base max-w-md mb-4">{destination.shortDesc}</p>
            <span className="inline-flex items-center gap-2 text-white text-sm font-semibold group-hover:gap-3 transition-all">
              Explore <ArrowRight size={16} />
            </span>
          </div>
        </Link>
      </article>
    );
  }

  return (
    <article className="group img-zoom rounded-2xl overflow-hidden bg-white shadow-sm hover:shadow-xl transition-shadow duration-500 animate-fade-up" style={{ animationDelay: `${(index % 4) * 60}ms` }}>
      <Link to={`/destinations/${destination.slug}`} className="block">
        <div className="relative aspect-[4/3] overflow-hidden">
          <img src={destination.image} alt={destination.name} className="w-full h-full object-cover" loading="lazy" />
          <div className="absolute top-3 left-3">
            <span className="chip bg-white/90 text-navy-700 border-transparent text-[0.65rem]">{destination.region}</span>
          </div>
        </div>
        <div className="p-5">
          <div className="flex items-center gap-1.5 text-xs text-ocean-400 mb-1.5">
            <MapPin size={13} /> {destination.country}
          </div>
          <h3 className="font-display font-bold text-xl text-navy-700 mb-1.5 group-hover:text-coral-500 transition-colors">{destination.name}</h3>
          <p className="text-sm text-navy-500/80 leading-relaxed line-clamp-2 mb-4">{destination.shortDesc}</p>
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-navy-500">{destination.duration}</span>
            <span className="inline-flex items-center gap-1 text-sm font-semibold text-coral-500 group-hover:gap-2 transition-all">
              Explore <ArrowRight size={14} />
            </span>
          </div>
        </div>
      </Link>
    </article>
  );
}
