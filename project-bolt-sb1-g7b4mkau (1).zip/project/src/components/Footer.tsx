import { useState } from 'react';
import { Instagram, Facebook, Youtube, Mail, MapPin, Phone, ArrowRight } from 'lucide-react';
import { Link, useRouter } from '@/router';
import { useStore } from '@/store/StoreContext';

const FOOTER_LINKS: Record<string, { label: string; to: string }[]> = {
  Explore: [
    { label: 'Destinations', to: '/destinations' },
    { label: 'Discover Japan', to: '/japan' },
    { label: 'Itineraries', to: '/itineraries' },
    { label: 'Travel Styles', to: '/japan#travel-styles' },
  ],
  Company: [
    { label: 'About Us', to: '/about' },
    { label: 'Contact', to: '/contact' },
    { label: 'Wishlist', to: '/wishlist' },
    { label: 'Trip Planner', to: '/trips' },
  ],
  Support: [
    { label: 'FAQ', to: '/faq' },
    { label: 'Privacy Policy', to: '/privacy' },
    { label: 'Terms & Conditions', to: '/terms' },
  ],
};

export function Footer() {
  const { notify } = useStore();
  const { navigate } = useRouter();
  const [email, setEmail] = useState('');

  const subscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      notify('Please enter a valid email address.');
      return;
    }
    notify('You are on the list. Travel inspiration incoming.');
    setEmail('');
  };

  return (
    <footer className="bg-navy-700 text-cloud-100 mt-20">
      <div className="container-page py-14 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8">
        <div className="col-span-2 md:col-span-2">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-coral-400 flex items-center justify-center">
              <MapPin size={16} className="text-white" strokeWidth={2.5} />
            </div>
            <span className="font-display font-extrabold text-2xl text-white tracking-tightest">ROAMORA</span>
          </Link>
          <p className="mt-4 text-sm text-cloud-200/70 max-w-xs leading-relaxed">
            The World Is Yours to Explore. Discover extraordinary places, find inspiring stays, and plan journeys worth remembering.
          </p>
          <div className="flex items-center gap-4 mt-5">
            <a href="#" aria-label="Instagram" className="text-cloud-200/60 hover:text-coral-400 transition-colors"><Instagram size={18} /></a>
            <a href="#" aria-label="Facebook" className="text-cloud-200/60 hover:text-coral-400 transition-colors"><Facebook size={18} /></a>
            <a href="#" aria-label="Youtube" className="text-cloud-200/60 hover:text-coral-400 transition-colors"><Youtube size={18} /></a>
          </div>
        </div>

        {Object.entries(FOOTER_LINKS).map(([heading, links]) => (
          <div key={heading}>
            <h4 className="text-[0.65rem] tracking-[0.25em] uppercase text-coral-400 font-semibold mb-4">{heading}</h4>
            <ul className="flex flex-col gap-2.5">
              {links.map((l) => (
                <li key={l.label}>
                  <button onClick={() => navigate(l.to)} className="text-sm text-cloud-200/70 hover:text-white transition-colors text-left">{l.label}</button>
                </li>
              ))}
            </ul>
          </div>
        ))}

        <div>
          <h4 className="text-[0.65rem] tracking-[0.25em] uppercase text-coral-400 font-semibold mb-4">Contact</h4>
          <ul className="flex flex-col gap-2.5 text-sm text-cloud-200/70">
            <li className="flex items-start gap-2"><Mail size={14} className="mt-0.5 shrink-0" /> hello@roamora.com</li>
            <li className="flex items-start gap-2"><Phone size={14} className="mt-0.5 shrink-0" /> +1 (555) 012-3456</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-navy-600">
        <div className="container-page py-8">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div>
              <h3 className="font-display font-bold text-xl text-white mb-1">Get travel inspiration</h3>
              <p className="text-sm text-cloud-200/60">New destinations, itineraries, and stories — delivered occasionally.</p>
            </div>
            <form onSubmit={subscribe} className="flex gap-2 max-w-md w-full">
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Your email address" aria-label="Email" className="flex-1 bg-navy-600 border border-navy-500 px-4 py-3 text-sm text-white placeholder:text-cloud-200/40 rounded-xl focus:outline-none focus:border-coral-400 transition-colors" />
              <button type="submit" className="bg-coral-400 text-white px-5 py-3 rounded-xl text-sm font-semibold hover:bg-coral-500 transition-colors flex items-center gap-1.5">
                Join <ArrowRight size={15} />
              </button>
            </form>
          </div>
        </div>
      </div>

      <div className="border-t border-navy-600">
        <div className="container-page py-5 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-cloud-200/40">
          <p>© 2026 ROAMORA. All rights reserved.</p>
          <p className="tracking-[0.15em] uppercase text-[0.6rem]">The World Is Yours to Explore.</p>
        </div>
      </div>
    </footer>
  );
}
