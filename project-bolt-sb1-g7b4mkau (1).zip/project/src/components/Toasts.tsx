import { CheckCircle2, X } from 'lucide-react';
import { useStore } from '@/store/StoreContext';

export function Toasts() {
  const { toasts, dismissToast } = useStore();
  return (
    <div className="fixed bottom-6 right-6 z-[60] flex flex-col gap-2.5 max-w-sm">
      {toasts.map((t) => (
        <div key={t.id} className="flex items-center gap-3 bg-navy-700 text-white px-4 py-3 rounded-xl shadow-lg animate-fade-up">
          <CheckCircle2 size={18} className="text-coral-400 shrink-0" />
          <span className="text-sm flex-1">{t.message}</span>
          <button onClick={() => dismissToast(t.id)} aria-label="Dismiss" className="text-cloud-200/50 hover:text-white"><X size={16} /></button>
        </div>
      ))}
    </div>
  );
}
