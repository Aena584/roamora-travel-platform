export type Region = 'Asia' | 'Europe' | 'Middle East' | 'Africa' | 'North America' | 'South America' | 'Oceania';

export type TravelStyle =
  | 'First-Time Japan Trip' | 'Japan on a Budget' | 'Luxury Japan' | 'Food Lover\'s Japan'
  | 'Traditional Japan' | 'Japan Nature Escape' | 'Anime & Pop Culture' | 'Family-Friendly Japan';

export interface Attraction {
  name: string;
  desc: string;
  image?: string;
}

export interface SeasonInfo {
  season: 'Spring' | 'Summer' | 'Autumn' | 'Winter';
  title: string;
  desc: string;
  image: string;
  recommendations: string[];
}

export interface Destination {
  id: string;
  slug: string;
  name: string;
  country: string;
  region: Region;
  image: string;
  gallery: string[];
  shortDesc: string;
  overview: string;
  attractions: Attraction[];
  activities: string[];
  bestTime: string;
  duration: string;
  budget: 'Budget' | 'Mid-range' | 'Luxury';
  travelStyles: string[];
  cultureEtiquette: string;
  transportation: string;
  featured?: boolean;
  countrySlug?: string;
}

export interface JapanCollection {
  id: string;
  name: string;
  tagline: string;
  desc: string;
  image: string;
  gallery: string[];
  highlights: string[];
  desc_long: string;
  season: string;
}

export interface ItineraryDay {
  day: number;
  title: string;
  desc: string;
}

export interface Itinerary {
  id: string;
  slug: string;
  title: string;
  duration: string;
  destinations: string[];
  style: string;
  budgetEstimate: string;
  budgetNotes: string;
  accommodation: string;
  days: ItineraryDay[];
}

export const SEASONS: SeasonInfo[] = [
  {
    season: 'Spring', title: 'Cherry Blossoms & Spring Gardens',
    desc: 'Sakura season transforms parks, temple grounds, and riversides with delicate pink blossoms. Timing varies by region and year — southern areas bloom first, moving northward over several weeks.',
    image: 'https://images.pexels.com/photos/4336279/pexels-photo-4336279.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    recommendations: ['Cherry blossom viewing in Tokyo and Kyoto', 'Strolling Philosopher\'s Path', 'Picnics at Ueno Park', 'Spring gardens in Kanazawa'],
  },
  {
    season: 'Summer', title: 'Festivals & Coastal Escapes',
    desc: 'Summer brings vibrant festivals (matsuri), fireworks, lush green landscapes, and coastal getaways. Expect warm, humid weather across most of the country.',
    image: 'https://images.pexels.com/photos/5219982/pexels-photo-5219982.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    recommendations: ['Gion Matsuri in Kyoto', 'Fuji Rock Festival', 'Beach escapes in Okinawa', 'Climbing Mount Fuji (July–August)'],
  },
  {
    season: 'Autumn', title: 'Colorful Foliage & Temple Gardens',
    desc: 'Autumn paints temple gardens and mountainsides in vivid reds, oranges, and golds. Foliage timing shifts by elevation and latitude, peaking later as you move north.',
    image: 'https://images.pexels.com/photos/35076911/pexels-photo-35076911.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    recommendations: ['Kiyomizu-dera autumn foliage', 'Tofuku-ji temple gardens', 'Momiji viewing in Arashiyama', 'Eikando temple light-up'],
  },
  {
    season: 'Winter', title: 'Snow Country & Seasonal Onsen',
    desc: 'Winter blankets Hokkaido and the Japanese Alps in deep snow, ideal for skiing, snow festivals, and soaking in steaming onsen hot springs.',
    image: 'https://images.pexels.com/photos/36053217/pexels-photo-36053217.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    recommendations: ['Sapporo Snow Festival', 'Skiing in Niseko, Hokkaido', 'Onsen retreats in Hakone', 'Snow monkeys in Jigokudani'],
  },
];

export const JAPAN_TRAVEL_STYLES: { id: string; title: TravelStyle; desc: string; icon: string }[] = [
  { id: 'first-time', title: 'First-Time Japan Trip', desc: 'Tokyo, Kyoto, and the classics — a perfect first introduction to Japan.', icon: 'Compass' },
  { id: 'budget', title: 'Japan on a Budget', desc: 'Smart travel with rail passes, affordable eats, and free sights.', icon: 'Wallet' },
  { id: 'luxury', title: 'Luxury Japan', desc: 'Five-star ryokans, private guides, kaiseki dining, and exclusive experiences.', icon: 'Crown' },
  { id: 'food', title: 'Food Lover\'s Japan', desc: 'From Tsukiji to Dotonbori — a culinary journey through Japan\'s food capitals.', icon: 'UtensilsCrossed' },
  { id: 'traditional', title: 'Traditional Japan', desc: 'Temples, tea ceremonies, ryokans, and Kyoto\'s living heritage.', icon: 'Landmark' },
  { id: 'nature', title: 'Japan Nature Escape', desc: 'Mount Fuji, Hokkaido\'s wilderness, national parks, and hot springs.', icon: 'Mountain' },
  { id: 'anime', title: 'Anime & Pop Culture', desc: 'Akihabara, Studio Ghibli, cosplay, and Japan\'s pop culture heart.', icon: 'Sparkles' },
  { id: 'family', title: 'Family-Friendly Japan', desc: 'Theme parks, interactive museums, and easy-paced family adventures.', icon: 'Users' },
];

export const JAPAN_COLLECTIONS: JapanCollection[] = [
  {
    id: 'tokyo', name: 'Tokyo', tagline: 'The City That Never Stops',
    desc: 'Modern city experiences, shopping districts, cultural landmarks, and endless food discoveries.',
    image: 'https://images.pexels.com/photos/35072452/pexels-photo-35072452.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/439741/pexels-photo-439741.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/31258209/pexels-photo-31258209.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/4162323/pexels-photo-4162323.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    highlights: ['Shibuya Crossing', 'Shinjuku', 'Asakusa', 'Senso-ji Temple', 'Tokyo Skytree', 'Akihabara', 'Harajuku'],
    desc_long: 'Tokyo is a city of exhilarating contrasts — where neon-lit districts pulse with energy and centuries-old temples sit quietly down the street. From the organized chaos of Shibuya Crossing to the serene grounds of Senso-ji, from anime-filled Akihabara to fashion-forward Harajuku, Tokyo rewards the curious at every turn.',
    season: 'Year-round; cherry blossoms in spring, festivals in summer',
  },
  {
    id: 'kyoto', name: 'Kyoto', tagline: 'A Journey Through Tradition',
    desc: 'Historic temples, traditional streets, bamboo groves, and Japan\'s living cultural heritage.',
    image: 'https://images.pexels.com/photos/29537651/pexels-photo-29537651.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/35076911/pexels-photo-35076911.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/33116224/pexels-photo-33116224.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/5745779/pexels-photo-5745779.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    highlights: ['Fushimi Inari Taisha', 'Kinkaku-ji (Golden Pavilion)', 'Arashiyama Bamboo Grove', 'Gion District', 'Kiyomizu-dera', 'Traditional streets'],
    desc_long: 'Kyoto is Japan\'s cultural heart, where a thousand years of tradition still breathe in temple gardens and narrow alleyways. Walk through the endless torii gates of Fushimi Inari, stand in the hush of the Arashiyama bamboo grove, and wander Gion at dusk when lanterns glow over wooden machiya houses.',
    season: 'Year-round; cherry blossoms spring, vivid foliage autumn',
  },
  {
    id: 'osaka', name: 'Osaka', tagline: 'Food, Fun & City Life',
    desc: 'Energetic atmosphere, entertainment districts, and Japan\'s most celebrated food culture.',
    image: 'https://images.pexels.com/photos/39037889/pexels-photo-39037889.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/28608381/pexels-photo-28608381.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/36834634/pexels-photo-36834634.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/33163115/pexels-photo-33163115.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    highlights: ['Dotonbori', 'Osaka Castle', 'Universal Studios Japan', 'Shinsekai', 'Street food tours'],
    desc_long: 'Osaka is Japan\'s kitchen — a city that lives to eat. The neon canals of Dotonbori glow over bustling food streets where takoyaki and okonomiyaki sizzle at every stall. Beyond the food, Osaka Castle and the retro charm of Shinsekai add history and character to this exuberant, unpretentious city.',
    season: 'Year-round; mild winters, warm humid summers',
  },
  {
    id: 'mount-fuji', name: 'Mount Fuji', tagline: 'Nature\'s Masterpiece',
    desc: 'Breathtaking landscapes, scenic lakes, and Japan\'s most iconic mountain.',
    image: 'https://images.pexels.com/photos/31710067/pexels-photo-31710067.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/31318845/pexels-photo-31318845.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/4336279/pexels-photo-4336279.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/31385052/pexels-photo-31385052.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    highlights: ['Mount Fuji viewpoints', 'Lake Kawaguchi', 'Chureito Pagoda', 'Fuji Five Lakes', 'Scenic nature trails'],
    desc_long: 'Mount Fuji is Japan\'s sacred symbol — a near-perfect cone rising from lakes and forests. The Fuji Five Lakes region offers the most iconic viewpoints, including the Chureito Pagoda framing the mountain with cherry blossoms in spring. Whether viewed from a distance or climbed in summer, Fuji is unforgettable.',
    season: 'Year-round; climbing season July–September; cherry blossoms April',
  },
  {
    id: 'hokkaido', name: 'Hokkaido', tagline: 'The Northern Escape',
    desc: 'Snow-covered winters, summer flower fields, and pristine wilderness.',
    image: 'https://images.pexels.com/photos/36053217/pexels-photo-36053217.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/20187344/pexels-photo-20187344.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/20187321/pexels-photo-20187321.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/20187394/pexels-photo-20187394.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    highlights: ['Snow-covered landscapes', 'Niseko ski resort', 'Furano flower fields', 'Biei scenic hills', 'Sapporo Snow Festival'],
    desc_long: 'Hokkaido is Japan\'s great northern wilderness — a world apart from the dense cities of the mainland. Winter brings deep powder snow and the famous Sapporo Snow Festival. Summer transforms Furano and Biei into rolling fields of lavender and wildflowers. Year-round, it offers outdoor adventure and untouched landscapes.',
    season: 'Winter (Dec–Feb) for snow; summer (Jul–Aug) for flower fields',
  },
  {
    id: 'hiroshima', name: 'Hiroshima', tagline: 'History & Reflection',
    desc: 'A city of peace, memory, and nearby Miyajima\'s floating shrine.',
    image: 'https://images.pexels.com/photos/18929392/pexels-photo-18929392.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/7204890/pexels-photo-7204890.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/30389535/pexels-photo-30389535.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/32008360/pexels-photo-32008360.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    highlights: ['Peace Memorial Park', 'Atomic Bomb Dome', 'Miyajima Island', 'Itsukushima Shrine', 'Floating torii gate'],
    desc_long: 'Hiroshima is a city of remembrance and resilience. The Peace Memorial Park and the preserved Atomic Bomb Dome stand as a moving tribute and a call for peace. Nearby, the island of Miyajima is home to the Itsukushima Shrine and its iconic floating torii gate — one of Japan\'s most photographed sights.',
    season: 'Year-round; mild and pleasant in spring and autumn',
  },
  {
    id: 'nara', name: 'Nara', tagline: 'Culture & Nature',
    desc: 'Ancient temples, sacred deer, and Japan\'s first permanent capital.',
    image: 'https://images.pexels.com/photos/31224887/pexels-photo-31224887.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/18848737/pexels-photo-18848737.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/30670640/pexels-photo-30670640.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/2070031/pexels-photo-2070031.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    highlights: ['Nara Park', 'Todai-ji Temple', 'Sacred deer', 'Kasuga Taisha', 'Traditional old streets'],
    desc_long: 'Nara was Japan\'s first permanent capital, and its park is home to hundreds of freely roaming sacred deer. The towering Todai-ji Temple houses one of the largest bronze Buddha statues in the world. Wander among moss-covered lanterns and ancient temples in this quietly profound city.',
    season: 'Year-round; cherry blossoms spring, deer most active autumn',
  },
  {
    id: 'okinawa', name: 'Okinawa', tagline: 'Island Escape',
    desc: 'Turquoise waters, coral reefs, and a distinctly different island culture.',
    image: 'https://images.pexels.com/photos/10964091/pexels-photo-10964091.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/27041999/pexels-photo-27041999.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/27041848/pexels-photo-27041848.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/5219982/pexels-photo-5219982.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    highlights: ['Turquoise beaches', 'Coral reef snorkeling', 'Coastal cliffs', 'Island culture', 'Okinawan cuisine'],
    desc_long: 'Okinawa offers a completely different atmosphere from Japan\'s mainland cities — a subtropical archipelago with turquoise waters, coral reefs, and a unique Ryukyuan culture. Life moves slower here, centenarians are common, and the beaches rival any in the Indian Ocean.',
    season: 'Year-round subtropical; best March–October; typhoons possible Jul–Sep',
  },
];

export const ITINERARIES: Itinerary[] = [
  {
    id: 'i5', slug: 'japan-highlights-5-days', title: '5-Day Japan Highlights',
    duration: '5 Days', destinations: ['Tokyo', 'Asakusa', 'Shibuya', 'Hakone'],
    style: 'First-Time Japan Trip', budgetEstimate: '$1,200–$1,800 per person',
    budgetNotes: 'Estimate for 2 travelers sharing mid-range accommodation. Excludes international flights. Includes domestic transport, accommodation, food, and activities.',
    accommodation: 'Mid-range hotels and one night in a Hakone ryokan',
    days: [
      { day: 1, title: 'Arrive in Tokyo', desc: 'Settle in, explore Shinjuku, first taste of Tokyo nightlife and ramen.' },
      { day: 2, title: 'Asakusa & Senso-ji', desc: 'Visit Senso-ji Temple, stroll Nakamise shopping street, Tokyo Skytree in the evening.' },
      { day: 3, title: 'Shibuya & Harajuku', desc: 'Shibuya Crossing, Meiji Shrine, Harajuku\'s Takeshita Street, Yoyogi Park.' },
      { day: 4, title: 'Day trip to Hakone', desc: 'Hot springs, Lake Ashi cruise, views of Mount Fuji, overnight ryokan stay.' },
      { day: 5, title: 'Final Tokyo exploration', desc: 'Akihabara or Ueno Park depending on interests, departure.' },
    ],
  },
  {
    id: 'i7', slug: 'japan-discovery-7-days', title: '7-Day Japan Discovery',
    duration: '7 Days', destinations: ['Tokyo', 'Kyoto', 'Fushimi Inari', 'Arashiyama'],
    style: 'First-Time Japan Trip', budgetEstimate: '$1,800–$2,600 per person',
    budgetNotes: 'Estimate for 2 travelers sharing mid-range accommodation. Excludes international flights. Includes Shinkansen, accommodation, food, and activities.',
    accommodation: 'Mid-range hotels in Tokyo and Kyoto',
    days: [
      { day: 1, title: 'Arrive in Tokyo', desc: 'Settle in, explore Shinjuku, welcome dinner in Shibuya.' },
      { day: 2, title: 'Tokyo classics', desc: 'Asakusa, Senso-ji, Tokyo Skytree, Ueno Park.' },
      { day: 3, title: 'Tokyo modern', desc: 'Shibuya, Harajuku, Meiji Shrine, teamLab digital art museum.' },
      { day: 4, title: 'Shinkansen to Kyoto', desc: 'Travel to Kyoto, afternoon in Gion district.' },
      { day: 5, title: 'Kyoto temples', desc: 'Fushimi Inari Taisha, Kinkaku-ji Golden Pavilion, Kiyomizu-dera.' },
      { day: 6, title: 'Arashiyama', desc: 'Bamboo grove, Tenryu-ji Temple, monkey park, riverside walk.' },
      { day: 7, title: 'Final Kyoto morning', desc: 'Nishiki Market, tea ceremony, departure.' },
    ],
  },
  {
    id: 'i10', slug: 'japan-explorer-10-days', title: '10-Day Japan Explorer',
    duration: '10 Days', destinations: ['Tokyo', 'Kyoto', 'Osaka', 'Nara'],
    style: 'First-Time Japan Trip', budgetEstimate: '$2,600–$3,800 per person',
    budgetNotes: 'Estimate for 2 travelers sharing mid-range accommodation. Excludes international flights. Includes Shinkansen, accommodation, food, and activities.',
    accommodation: 'Mid-range hotels with one ryokan night in Kyoto',
    days: [
      { day: 1, title: 'Arrive in Tokyo', desc: 'Settle in, evening in Shinjuku.' },
      { day: 2, title: 'Tokyo highlights', desc: 'Asakusa, Senso-ji, Shibuya Crossing, Harajuku.' },
      { day: 3, title: 'Tokyo deep dive', desc: 'Meiji Shrine, teamLab, Akihabara, dinner in Ginza.' },
      { day: 4, title: 'Day trip to Hakone', desc: 'Onsen, Lake Ashi, Mount Fuji views.' },
      { day: 5, title: 'Shinkansen to Kyoto', desc: 'Travel, Gion district evening walk.' },
      { day: 6, title: 'Kyoto classics', desc: 'Fushimi Inari, Kinkaku-ji, Kiyomizu-dera.' },
      { day: 7, title: 'Arashiyama & Nara', desc: 'Bamboo grove morning, afternoon with Nara\'s sacred deer.' },
      { day: 8, title: 'Day trip to Osaka', desc: 'Osaka Castle, Dotonbori street food evening.' },
      { day: 9, title: 'Osaka & Universal', desc: 'Universal Studios Japan or Shinsekai and local neighborhoods.' },
      { day: 10, title: 'Departure', desc: 'Final morning, travel home.' },
    ],
  },
  {
    id: 'i14', slug: 'japan-grand-journey-14-days', title: '14-Day Japan Grand Journey',
    duration: '14 Days', destinations: ['Tokyo', 'Hakone', 'Kyoto', 'Osaka', 'Hiroshima', 'Miyajima'],
    style: 'Luxury Japan', budgetEstimate: '$4,500–$6,500 per person',
    budgetNotes: 'Estimate for 2 travelers sharing mid-to-upper-range accommodation. Excludes international flights. Includes Shinkansen, accommodation, dining, and curated activities.',
    accommodation: 'Upper-range hotels, two ryokan stays (Hakone and Kyoto)',
    days: [
      { day: 1, title: 'Arrive in Tokyo', desc: 'Settle in, welcome dinner in a Ginza restaurant.' },
      { day: 2, title: 'Tokyo classics', desc: 'Asakusa, Senso-ji, Shibuya Crossing, Harajuku.' },
      { day: 3, title: 'Tokyo culture', desc: 'Meiji Shrine, teamLab, Nezu Museum gardens, Akihabara.' },
      { day: 4, title: 'Tokyo day trip', desc: 'Kamakura — Great Buddha, temples, seaside.' },
      { day: 5, title: 'Hakone retreat', desc: 'Travel to Hakone, luxury ryokan, onsen, Lake Ashi.' },
      { day: 6, title: 'Shinkansen to Kyoto', desc: 'Travel, afternoon tea ceremony in Gion.' },
      { day: 7, title: 'Kyoto temples', desc: 'Fushimi Inari, Kinkaku-ji, Ryoan-ji zen garden.' },
      { day: 8, title: 'Kyoto further', desc: 'Kiyomizu-dera, Arashiyama bamboo grove, riverside lunch.' },
      { day: 9, title: 'Nara day trip', desc: 'Nara Park, Todai-ji, sacred deer, return to Kyoto.' },
      { day: 10, title: 'To Osaka', desc: 'Travel, Osaka Castle, evening in Dotonbori.' },
      { day: 11, title: 'Osaka experiences', desc: 'Food tour, Shinsekai, or Universal Studios Japan.' },
      { day: 12, title: 'Shinkansen to Hiroshima', desc: 'Travel, Peace Memorial Park, Atomic Bomb Dome.' },
      { day: 13, title: 'Miyajima Island', desc: 'Itsukushima Shrine, floating torii gate, Mount Misen.' },
      { day: 14, title: 'Return & depart', desc: 'Shinkansen back to Tokyo or Osaka, departure.' },
    ],
  },
];

export const DESTINATIONS: Destination[] = [
  {
    id: 'd1', slug: 'japan', name: 'Japan', country: 'East Asia', region: 'Asia',
    image: 'https://images.pexels.com/photos/31710067/pexels-photo-31710067.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/31258209/pexels-photo-31258209.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/29537651/pexels-photo-29537651.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/39037889/pexels-photo-39037889.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/4336279/pexels-photo-4336279.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    shortDesc: 'Ancient culture and modern life meet — from Tokyo\'s electric energy to Kyoto\'s timeless temples.',
    overview: 'Japan is a country of profound contrasts, where bullet trains glide past centuries-old temples and neon-lit districts sit beside serene gardens. It is at once deeply traditional and relentlessly modern, meticulously orderly and wonderfully surprising. From the cherry blossoms of spring to the snow festivals of winter, Japan rewards travelers across every season.',
    attractions: [
      { name: 'Mount Fuji', desc: 'Japan\'s sacred icon, visible from Tokyo on clear days and best experienced from the Fuji Five Lakes region.', image: 'https://images.pexels.com/photos/31710067/pexels-photo-31710067.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Fushimi Inari Taisha', desc: 'Endless rows of vermilion torii gates winding up a mountainside in Kyoto.', image: 'https://images.pexels.com/photos/29537651/pexels-photo-29537651.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Shibuya Crossing', desc: 'The world\'s busiest pedestrian intersection, the pulse of modern Tokyo.', image: 'https://images.pexels.com/photos/35072452/pexels-photo-35072452.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Arashiyama Bamboo Grove', desc: 'A towering, ethereal bamboo forest on the outskirts of Kyoto.', image: 'https://images.pexels.com/photos/33116224/pexels-photo-33116224.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Itsukushima Shrine', desc: 'The floating torii gate of Miyajima, one of Japan\'s most iconic views.', image: 'https://images.pexels.com/photos/18929392/pexels-photo-18929392.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
    ],
    activities: ['Temple and shrine visits', 'Cherry blossom viewing (spring)', 'Onsen hot spring bathing', 'Sushi and ramen culinary tours', 'Shinkansen bullet train travel', 'Traditional tea ceremony', 'Hiking Mount Fuji (summer)', 'Autumn foliage viewing'],
    bestTime: 'Spring (March–May) for cherry blossoms and Autumn (October–November) for foliage are most popular. Winter offers snow and fewer crowds. Summer is warm and humid with lively festivals.',
    duration: '7–14 days for a first trip covering Tokyo, Kyoto, and one other region.',
    budget: 'Mid-range',
    travelStyles: ['First-Time Japan Trip', 'Traditional Japan', 'Food Lover\'s Japan', 'Japan Nature Escape'],
    cultureEtiquette: 'Bowing is the common greeting. Remove shoes when entering homes, temples, and traditional accommodations. Speak quietly on public transport. Avoid eating while walking. Tip is not expected anywhere. Carry cash, as some smaller places do not accept cards.',
    transportation: 'The Japan Rail Pass is excellent value for long-distance travel. Shinkansen trains connect major cities at 300 km/h. Within cities, use the efficient subway and IC cards (Suica/Pasmo) for tap-and-go transit.',
    featured: true, countrySlug: 'japan',
  },
  {
    id: 'd2', slug: 'switzerland', name: 'Switzerland', country: 'Central Europe', region: 'Europe',
    image: 'https://images.pexels.com/photos/20385882/pexels-photo-20385882.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/20385883/pexels-photo-20385883.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/8626748/pexels-photo-8626748.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/40090812/pexels-photo-40090812.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    shortDesc: 'Alpine peaks, turquoise lakes, and storybook villages connected by the world\'s best trains.',
    overview: 'Switzerland is a country of staggering natural beauty, where snow-capped Alps rise above crystal-clear lakes and verdant valleys. Its villages feel plucked from a storybook, connected by one of the world\'s most precise and scenic rail networks. Whether skiing in Zermatt or hiking in the Lauterbrunnen Valley, the Alps never fail to inspire.',
    attractions: [
      { name: 'The Swiss Alps', desc: 'Iconic peaks including the Matterhorn and Jungfrau, accessible by scenic mountain railways.', image: 'https://images.pexels.com/photos/20385882/pexels-photo-20385882.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Lake Lucerne', desc: 'A dramatic lake surrounded by mountains, best explored by paddle steamer.', image: 'https://images.pexels.com/photos/8626748/pexels-photo-8626748.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Lauterbrunnen Valley', desc: 'A valley of 72 waterfalls beneath sheer cliff walls.', image: 'https://images.pexels.com/photos/20385883/pexels-photo-20385883.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
    ],
    activities: ['Scenic train journeys (Glacier Express, Bernina Express)', 'Alpine hiking and skiing', 'Lake cruises', 'Exploring medieval towns', 'Cheese and chocolate tasting', 'Cable car mountain ascents'],
    bestTime: 'June–September for hiking and lake activities. December–March for skiing. Spring and autumn are quieter and beautiful.',
    duration: '5–10 days',
    budget: 'Luxury',
    travelStyles: ['Luxury Japan', 'Japan Nature Escape'],
    cultureEtiquette: 'Punctuality is highly valued. Greet with a handshake. Keep voices low in public. Swiss German, French, Italian, and Romansh are all national languages.',
    transportation: 'The Swiss Travel Pass covers trains, buses, and boats nationwide. Trains are the best way to see the country.',
    featured: true,
  },
  {
    id: 'd3', slug: 'italy', name: 'Italy', country: 'Southern Europe', region: 'Europe',
    image: 'https://images.pexels.com/photos/17855614/pexels-photo-17855614.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/18847929/pexels-photo-18847929.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/16890263/pexels-photo-16890263.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/18781088/pexels-photo-18781088.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    shortDesc: 'Canals of Venice, cliffs of Amalfi, and a thousand years of art, food, and la dolce vita.',
    overview: 'Italy is a country that celebrates life. From the Renaissance art of Florence to the canals of Venice, from the ancient ruins of Rome to the cliffside villages of the Amalfi Coast, Italy weaves beauty, history, and culinary pleasure into every experience. It is a country best enjoyed slowly, with a glass of wine and a long lunch.',
    attractions: [
      { name: 'Venice Canals', desc: 'Romantic waterways, gondolas, and centuries of history sinking slowly into the lagoon.', image: 'https://images.pexels.com/photos/18847929/pexels-photo-18847929.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Amalfi Coast', desc: 'Pastel villages clinging to dramatic cliffs above the turquoise Mediterranean.', image: 'https://images.pexels.com/photos/17855614/pexels-photo-17855614.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Colosseum, Rome', desc: 'The iconic arena of ancient Rome, nearly 2,000 years old.', image: 'https://images.pexels.com/photos/16890263/pexels-photo-16890263.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
    ],
    activities: ['Gondola rides in Venice', 'Wine tasting in Tuscany', 'Pompeii archaeological site', 'Coastal driving', 'Cooking classes', 'Renaissance art tours in Florence', 'Amalfi Coast boat trips'],
    bestTime: 'April–June and September–October for mild weather and fewer crowds. July–August is hot and busy.',
    duration: '7–14 days',
    budget: 'Mid-range',
    travelStyles: ['First-Time Japan Trip', 'Food Lover\'s Japan'],
    cultureEtiquette: 'Dress modestly when visiting churches. Cappuccino is a morning drink. Meals are social and unhurried. A small "coperto" cover charge is normal at restaurants.',
    transportation: 'High-speed trains (Frecciarossa) connect major cities. Regional trains serve smaller towns. A car is useful for countryside and coast.',
    featured: true,
  },
  {
    id: 'd4', slug: 'turkiye', name: 'Türkiye', country: 'Anatolia', region: 'Middle East',
    image: 'https://images.pexels.com/photos/12756936/pexels-photo-12756936.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/4279431/pexels-photo-4279431.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/27260270/pexels-photo-27260270.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/32424310/pexels-photo-32424310.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    shortDesc: 'Where Europe meets Asia — Cappadocia\'s balloons, Istanbul\'s bazaars, and ancient wonders.',
    overview: 'Türkiye bridges two continents and countless civilizations. Istanbul\'s skyline of domes and minarets overlooks the Bosphorus, while Cappadocia\'s fairy chimneys rise from surreal landscapes. Ancient ruins at Ephesus, the thermal pools of Pamukkale, and the turquoise coast of Antalya round out a country of remarkable depth.',
    attractions: [
      { name: 'Cappadocia', desc: 'Surreal rock formations and sunrise hot air balloon rides over a lunar landscape.', image: 'https://images.pexels.com/photos/12756936/pexels-photo-12756936.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Hagia Sophia, Istanbul', desc: 'A 1,500-year-old architectural marvel, church and mosque and museum.', image: 'https://images.pexels.com/photos/27260270/pexels-photo-27260270.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Pamukkale', desc: 'Brilliant white travertine terraces of thermal water cascading down a hillside.', image: 'https://images.pexels.com/photos/32424310/pexels-photo-32424310.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
    ],
    activities: ['Hot air balloon rides in Cappadocia', 'Bazaar shopping in Istanbul', 'Hammam bath houses', 'Ephesus ancient city', 'Turkish cuisine and tea culture', 'Whirling dervish performances', 'Beach resorts on the Turquoise Coast'],
    bestTime: 'April–June and September–October for mild weather. Cappadocia balloons fly year-round weather permitting.',
    duration: '7–10 days',
    budget: 'Mid-range',
    travelStyles: ['First-Time Japan Trip', 'Family-Friendly Japan'],
    cultureEtiquette: 'Dress modestly at mosques (head covering for women). Remove shoes when entering homes. Tea is a symbol of hospitality and hard to refuse.',
    transportation: 'Domestic flights connect Istanbul to Cappadocia and coastal cities. Buses are comfortable and extensive. A car helps for rural exploration.',
    featured: true,
  },
  {
    id: 'd5', slug: 'indonesia', name: 'Indonesia', country: 'Southeast Asia', region: 'Asia',
    image: 'https://images.pexels.com/photos/17716409/pexels-photo-17716409.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/35428411/pexels-photo-35428411.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/34136180/pexels-photo-34136180.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/39472103/pexels-photo-39472103.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    shortDesc: 'Temples in the jungle, terraced rice fields, volcanoes, and some of the world\'s best beaches.',
    overview: 'Indonesia is an archipelago of over 17,000 islands, but Bali is its beating heart — a place where Hindu temples rise from emerald rice terraces, surf breaks roll onto golden sand, and a deeply spiritual culture infuses daily life. Beyond Bali, Yogyakarta, Komodo, and Lombok offer wilder adventures.',
    attractions: [
      { name: 'Bali Rice Terraces', desc: 'The UNESCO-listed Jatiluwih and Tegalalang terraces, sculpted over centuries.', image: 'https://images.pexels.com/photos/35428411/pexels-photo-35428411.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Balinese Temples', desc: 'Sea temples and mountain shrines, from Tanah Lot to Besakih.', image: 'https://images.pexels.com/photos/17716409/pexels-photo-17716409.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Mount Agung', desc: 'Bali\'s sacred volcano, towering over the eastern landscape.', image: 'https://images.pexels.com/photos/34136180/pexels-photo-34136180.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
    ],
    activities: ['Surfing at Uluwatu and Canggu', 'Rice terrace hiking', 'Temple visits', 'Snorkeling and diving', 'Yoga retreats in Ubud', 'Volcano sunrise hikes', 'Traditional cooking classes'],
    bestTime: 'April–October for dry season. May–September is ideal. Wet season runs November–March.',
    duration: '7–14 days',
    budget: 'Budget',
    travelStyles: ['Japan Nature Escape', 'Japan on a Budget'],
    cultureEtiquette: 'Dress modestly at temples (sarong and sash often provided). Use right hand for giving and eating. Avoid pointing with feet.',
    transportation: 'Scooters are the most common way to get around Bali. Private drivers are affordable. Domestic flights connect islands.',
    featured: true,
  },
  {
    id: 'd6', slug: 'thailand', name: 'Thailand', country: 'Southeast Asia', region: 'Asia',
    image: 'https://images.pexels.com/photos/31027077/pexels-photo-31027077.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/31027070/pexels-photo-31027070.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/4238006/pexels-photo-4238006.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/31027063/pexels-photo-31027063.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    shortDesc: 'Golden temples, floating markets, street food, and tropical islands along the Andaman Sea.',
    overview: 'Thailand is the land of smiles — a country where gilded temples, bustling floating markets, and some of the world\'s best street food coexist with palm-fringed islands and limestone karsts. From the temples of Bangkok to the beaches of Phuket and Krabi, Thailand delivers warmth, flavor, and beauty at every turn.',
    attractions: [
      { name: 'Bangkok Canals', desc: 'Longtail boats glide through khlongs past wooden houses and floating markets.', image: 'https://images.pexels.com/photos/31027077/pexels-photo-31027077.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Grand Palace', desc: 'The dazzling former royal residence and home of the Emerald Buddha.', image: 'https://images.pexels.com/photos/4238006/pexels-photo-4238006.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Andaman Coast', desc: 'Limestone cliffs and turquoise waters of Phang Nga Bay and Krabi.', image: 'https://images.pexels.com/photos/31027063/pexels-photo-31027063.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
    ],
    activities: ['Temple tours in Bangkok', 'Floating market visits', 'Island hopping to Phi Phi', 'Thai cooking classes', 'Street food tours', 'Elephant sanctuaries (ethical)', 'Scuba diving in the Similans'],
    bestTime: 'November–March for cool, dry weather. April is hottest. May–October is monsoon season (varies by coast).',
    duration: '7–14 days',
    budget: 'Budget',
    travelStyles: ['Japan on a Budget', 'Food Lover\'s Japan'],
    cultureEtiquette: 'Do not touch the head. Remove shoes at temples and homes. The monarchy is deeply respected — avoid any disrespectful comments. Wai (prayer-like bow) is the traditional greeting.',
    transportation: 'Low-cost domestic flights connect Bangkok to islands and the north. Overnight trains to Chiang Mai. Ferries and speedboats between islands.',
    featured: true,
  },
  {
    id: 'd7', slug: 'south-korea', name: 'South Korea', country: 'East Asia', region: 'Asia',
    image: 'https://images.pexels.com/photos/19751382/pexels-photo-19751382.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/37436292/pexels-photo-37436292.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/29562547/pexels-photo-29562547.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/30997440/pexels-photo-30997440.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    shortDesc: 'Palaces and skyscrapers, K-pop and centuries of tradition, mountains and street food.',
    overview: 'South Korea is a country where ancient dynasties and cutting-edge technology exist side by side. Seoul\'s royal palaces stand in the shadow of gleaming skyscrapers, while Bukchon\'s hanok village preserves traditional architecture. Beyond the capital, Busan\'s coast and Jeju\'s volcanic landscapes add natural beauty to a deeply cultural journey.',
    attractions: [
      { name: 'Gyeongbokgung Palace', desc: 'The grand Joseon-era royal palace in the heart of Seoul.', image: 'https://images.pexels.com/photos/19751382/pexels-photo-19751382.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Bukchon Hanok Village', desc: 'Centuries-old traditional Korean houses preserved on a hillside.', image: 'https://images.pexels.com/photos/29562547/pexels-photo-29562547.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Jeju Island', desc: 'Volcanic landscapes, lava tubes, and waterfalls off the southern coast.', image: 'https://images.pexels.com/photos/37436292/pexels-photo-37436292.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
    ],
    activities: ['Palace tours in Seoul', 'Korean BBQ and street food in Myeongdong', 'K-pop and entertainment district tours', 'Hanok village walks', 'Jeju Island hiking', 'Korean spa (jjimjilbang)', 'Temple stays'],
    bestTime: 'April–June and September–November for mild weather. Spring brings cherry blossoms; autumn brings vivid foliage.',
    duration: '5–10 days',
    budget: 'Mid-range',
    travelStyles: ['First-Time Japan Trip', 'Anime & Pop Culture'],
    cultureEtiquette: 'Use two hands when giving or receiving. Remove shoes indoors. Bowing is customary. Avoid writing names in red ink.',
    transportation: 'KTX high-speed trains connect Seoul, Busan, and other cities. Seoul\'s subway is comprehensive and English-friendly.',
    featured: true,
  },
  {
    id: 'd8', slug: 'maldives', name: 'Maldives', country: 'Indian Ocean', region: 'Asia',
    image: 'https://images.pexels.com/photos/9394274/pexels-photo-9394274.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    gallery: [
      'https://images.pexels.com/photos/3155696/pexels-photo-3155696.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/9080959/pexels-photo-9080959.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      'https://images.pexels.com/photos/1724430/pexels-photo-1724430.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    ],
    shortDesc: 'Overwater villas, coral reefs, and pure turquoise water — the ultimate island escape.',
    overview: 'The Maldives is a nation of nearly 1,200 islands spread across the Indian Ocean, known for overwater bungalows, vibrant coral reefs, and water so clear it seems unreal. It is the definition of a barefoot luxury escape — a place to snorkel with manta rays in the morning and watch bioluminescent shores at night.',
    attractions: [
      { name: 'Overwater Villas', desc: 'Iconic thatched-roof bungalows perched above turquoise lagoons.', image: 'https://images.pexels.com/photos/9394274/pexels-photo-9394274.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Coral Reefs', desc: 'Some of the world\'s best snorkeling and diving among vibrant marine life.', image: 'https://images.pexels.com/photos/3155696/pexels-photo-3155696.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
      { name: 'Malé Markets', desc: 'The bustling capital, a contrast to the serenity of the resorts.', image: 'https://images.pexels.com/photos/1724430/pexels-photo-1724430.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
    ],
    activities: ['Snorkeling and diving', 'Island hopping', 'Sunset dolphin cruises', 'Bioluminescent beach walks', 'Spa and wellness', 'Fishing excursions', 'Sandbank picnics'],
    bestTime: 'November–April for dry, sunny weather. May–October brings warmer, wetter conditions (lower prices).',
    duration: '5–7 days',
    budget: 'Luxury',
    travelStyles: ['Luxury Japan', 'Japan Nature Escape'],
    cultureEtiquette: 'Maldives is a Muslim country. Resort islands are relaxed, but inhabited islands require modest dress. No alcohol outside resorts.',
    transportation: 'Speedboat or seaplane transfers from Malé to your resort island. Domestic flights for outer atolls.',
    featured: true,
  },
];

export function getDestination(slug: string): Destination | undefined {
  return DESTINATIONS.find((d) => d.slug === slug);
}

export function getJapanCollection(id: string): JapanCollection | undefined {
  return JAPAN_COLLECTIONS.find((c) => c.id === id);
}

export function getItinerary(slug: string): Itinerary | undefined {
  return ITINERARIES.find((i) => i.slug === slug);
}

export const REGIONS: Region[] = ['Asia', 'Europe', 'Middle East', 'Africa', 'North America', 'South America', 'Oceania'];
export const BUDGETS = ['Budget', 'Mid-range', 'Luxury'] as const;
export const TRAVEL_STYLES_ALL = JAPAN_TRAVEL_STYLES.map((s) => s.title);
